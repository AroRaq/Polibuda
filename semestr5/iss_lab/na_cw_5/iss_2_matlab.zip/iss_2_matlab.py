#%%

from control import matlab
from control import tf
import matplotlib.pyplot as plt
import numpy as np
from Chart import Chart

G = tf([0,0,0,2],
       [1,5,4,3])

t = np.arange(0, 200, 0.05)

def GetPID(Kp, Ki, Kd):
    return tf([Kd, Kp, Ki],
              [0,1,0])

def calculate_pid(k, Ti, Td, target):
    Kp = k
    Ki = k/Ti if Ti != None else 0
    Kd = k*Td if Td != None else 0
    PID = GetPID(Kp, Ki, Kd)
    feed = matlab.feedback(PID * G, 1/target)
    Y, T = matlab.step(feed, t)
    return T, Y

k = 5
Ti = 100
Td = 2
target = 2
chart = Chart(k, Ti, Td, 2*target, lambda _k,_Ti,_Td: calculate_pid(_k, _Ti, _Td, target))

# %%
