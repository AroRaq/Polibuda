import React, { Component } from "react";

export class HomePage extends Component {
  static displayName = HomePage.name;

  render() {
    return (
      <div>
        <h1>Hello, world!</h1>
        <p>Welcome to your new single-page application, built with:</p>
      </div>
    );
  }
}
