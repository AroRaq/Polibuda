import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MyClient {
    public static void main(String[] args) {
        CalcObject zObiekt;
        CalcObject zObiekt2;
        InputType inObj;
        if (args.length <= 1) {
            System.out.println("You have to enter two RMI object address in the form: // host_address/service_name ");
            return;
        }


        Scanner scanner = new Scanner(System.in);
        try{
            System.out.println("Podaj ilosc zestawow danych:");
            int dataCount = scanner.nextInt();
            ArrayList<InputType> inputs = new ArrayList<InputType>(dataCount);
            for (int i = 0; i < dataCount; i++){
                System.out.println("Podaj dane dla zestawu " + (i+1) + ":");
                inputs.add(getInput(scanner));
            }

            try {
                zObiekt = (CalcObject) java.rmi.Naming.lookup(args[0]);
                zObiekt2 = (CalcObject) java.rmi.Naming.lookup(args[0]);
            } catch (Exception e) {
                System.out.println("Nie mozna pobrac referencji");
                e.printStackTrace();
                return;
            }
            System.out.println("Referencja do "+args[0]+" jest pobrana.");
            System.out.println("Referencja do "+args[1]+" jest pobrana.");

            ArrayList<ResultType> results = new ArrayList<ResultType>(inputs.size());
            for(int i = 0; i < inputs.size(); i++){
                if(i%2 ==0){
                    results.add(zObiekt.calculate(inputs.get(i)));
                }else{
                    results.add(zObiekt2.calculate(inputs.get(i)));
                }
            }
            for(int i = 0; i < results.size(); i++){
                ResultType result = results.get(i);
                SimpleDateFormat formatter = new SimpleDateFormat("HH:mm:ss.SSS");
                String strTime = formatter.format(result.time);
                System.out.println("Wynik dla " + (i+1) + " zestawu danych: " +
                        "     max=" + result.max +
                        "     count=" + result.count +
                        "     med=" + result.med +
                        "     time=" + strTime);
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    private static InputType getInput(Scanner scanner) {
        try {
            System.out.print("Podaj x: ");
            long l1 = scanner.nextLong();
            if (l1 < 0) {
                System.out.println("Liczba x musi byc dodatnia!");
                scanner.nextLine();
                return getInput(scanner);
            }
            System.out.print("Podaj y: ");
            long l2 = scanner.nextLong();
            if (l2 < 0) {
                System.out.println("Liczba y musi byc dodatnia!");
                scanner.nextLine();
                return getInput(scanner);
            }
            InputType result = new InputType();
            if (l2 < l1) {
                System.out.println("Liczba y nie moze byc mniejsza niz x!");
                scanner.nextLine();
                return getInput(scanner);
            }
            result.x = l1;
            result.y = l2;
            System.out.println();
            return result;
        } catch (Exception e){
            System.out.println("Niepoprawny format danych!!");
            scanner.nextLine();
            return getInput(scanner);
        }
    }
}