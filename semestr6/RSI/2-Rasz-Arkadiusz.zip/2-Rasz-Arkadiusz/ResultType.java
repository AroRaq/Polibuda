import java.io.Serializable;
import java.util.Date;

public class ResultType implements Serializable {
    private static final long serialVersionUID = 102L;
    public long max;
    public long count;
    public long med;
    public Date time;
}
