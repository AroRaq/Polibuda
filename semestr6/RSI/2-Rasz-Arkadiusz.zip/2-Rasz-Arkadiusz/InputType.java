import java.io.Serializable;

public class InputType implements Serializable {
    private static final long serialVersionUID = 101L;
    public long x;
    public long y;

    public long getX() {
        return x;
    }
    public long getY() {
        return y;
    }
}
