import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.lang.Math;
import java.util.*;

public class CalcObjImpl extends UnicastRemoteObject
        implements CalcObject
{
    private static final long serialVersionUID = 101L;
    private long _count = 0;
    private long _max = 0;
    private long _med = 0;

    public CalcObjImpl() throws RemoteException {
        super();
    }

    public ResultType calculate(InputType we)
            throws RemoteException {
        _count = 0;
        _max = 0;
        long x = we.getX();
        long y = we.getY();
        podzad1(x, y);
        podzad2(x, y);
        ResultType result = new ResultType();
        result.max = _max;
        result.med = _med;
        result.count = _count;
        result.time = new Date();
        return result;
    }

    private void podzad1(long x, long y) {
        for (long i = x; i <= y; i++) {
            if (isPrime(i)) {
                _count++;
                _max = i;
            }
        }
    }

    private long podzad2(long x, long y) {
        Random random = new Random();
        ArrayList<Long> list = new ArrayList<Long>();
        for (int i = 0; i <= 10000000; i++) {
            long num = x + (long)(random.nextDouble() * (y-x));
            list.add(num);
        }
        Collections.sort(list);
        _med = list.get(5000001);
        return _med;
    }


    private boolean isPrime(long x) {
        if (x % 2 == 0)
            return false;
        for (int i = 3; i < Math.sqrt(x); i+=2) {
            if (x % i == 0)
                return false;
        }

        return true;
    }
}