﻿using System;
using System.ServiceModel;
using System.Threading;
using WcfServiceClient.ServiceReference1;
using WcfServiceClient.ServiceReference2;
using WcfServiceClient.ServiceReference3;

namespace WcfServiceClient
{
    class Program
    {
        static void Main(string[] args)
        {
            KalkulatorLZClient klient1 = new KalkulatorLZClient("WSHttpBinding_IKalkulatorLZ");
            LiczbaZ lz1 = new LiczbaZ();
            lz1.czescR = 1.2;
            lz1.czescU = 3.4;
            LiczbaZ lz2 = new LiczbaZ();
            lz2.czescR = 5.6;
            lz2.czescU = -7.8;
            Console.WriteLine("\nKLIENT1");
            Console.WriteLine("...wywoluje DodajLZ(...)");
            LiczbaZ result1 = klient1.DodajLZ(lz1, lz2);
            Console.WriteLine(" DodajLZ(...) = ({0} , {1})",
            result1.czescR, result1.czescU);
            klient1.Close();
            Console.WriteLine("KONIEC KLIENT1");

            OWSerwisClient klient2 = new
             OWSerwisClient("BasicHttpBinding_IOWSerwis");
            Console.WriteLine("\nKLIENT2");
            Console.WriteLine("...wywoluje funkcja 1:");
            klient2.Funkcja1("Klient2");
            Thread.Sleep(10);
            Console.WriteLine("...kontynuacja po funkcji 1");
            Console.WriteLine("...wywoluje funkcja 2:");
            klient2.Funkcja2("Klient2");
            Thread.Sleep(10);
            Console.WriteLine("...kontynuacja po funkcji 2");
            klient2.Close();
            Console.WriteLine("KONIEC KLIENT2");

            Console.WriteLine("\nKLIENT3:");
            CallbackHandler mojCallbackHandler = new CallbackHandler();
            InstanceContext instanceContext = new InstanceContext(mojCallbackHandler);
            CallbackKalkulatorClient klient3 = new CallbackKalkulatorClient(instanceContext);
            Console.WriteLine("...wywoluje Silnia(10)");
            klient3.Silnia(10);
            Console.WriteLine("...wywoluje Silnia(20)");
            klient3.Silnia(20);
            Console.WriteLine("...wywoluje obliczenia cosia...");
            klient3.ObliczCos(2);
            Console.WriteLine("...poczekaj chwile na odbior wynikow");
            Console.WriteLine("-->naciśnij <ENTER> aby zakoczyć");
            Console.ReadLine();
            Thread.Sleep(5000);
            klient3.Close();
            Console.WriteLine("KONIEC KLIENT3");
        }
    }
}
