﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using WcfServiceCallback;
using WcfServiceContract;

namespace WcfServiceHost
{
    class Program
    {
        static void Main(string[] args)
        {
            Uri baseAddress1 = new Uri("http://localhost:10018/service");
            ServiceHost mojHost1 = new ServiceHost(typeof(KalkulatorLZ), baseAddress1);
            Uri baseAddress2 = new Uri("http://localhost:10019/owservice");
            ServiceHost mojHost2 = new ServiceHost(typeof(MojSerwis2), baseAddress2);
            Uri baseAddress3 = new Uri("http://localhost:30018");
            ServiceHost mojHost3 = new ServiceHost(typeof(mojCallbackKalkulator), baseAddress3);
            try
            {
                // Metadane:
                ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
                smb.HttpGetEnabled = true;

                ServiceEndpoint endpoint1 = mojHost1.AddServiceEndpoint(
                 typeof(IKalkulatorLZ),
                 new WSHttpBinding(),
                 "endpoint1");
                mojHost1.Description.Behaviors.Add(smb);
                mojHost1.Open();
                Console.WriteLine("--->KalkulatorLZ jest uruchomiony.");

                smb = new ServiceMetadataBehavior();    //jak się korzysta z tego samego to widzi poprzednie endpointy
                smb.HttpGetEnabled = true;

                ServiceEndpoint endpoint2 = mojHost2.AddServiceEndpoint(
                    typeof(IOWSerwis),
                     new BasicHttpBinding(),
                 "endpoint2");
                mojHost2.Description.Behaviors.Add(smb);
                mojHost2.Open();
                Console.WriteLine("--->Serwis 2 jest uruchomiony.");

                smb = new ServiceMetadataBehavior();    //jak się korzysta z tego samego to widzi poprzednie endpointy
                smb.HttpGetEnabled = true;

                ServiceEndpoint endpoint3 = mojHost3.AddServiceEndpoint(
                    typeof(ICallbackKalkulator),
                 new WSDualHttpBinding(), 
                 "CallbackKalkulator");
                mojHost3.Description.Behaviors.Add(smb);
                mojHost3.Open();
                Console.WriteLine("--->CallbackKalkulator uruchomiony.");

                Console.WriteLine("--->Nacisnij <ENTER> aby zakonczyc.\n");
                Console.ReadLine(); //czekam na zamkniecie
                mojHost1.Close();
                Console.WriteLine("---> Serwis zakonczyl dzialanie.");
            }
            catch (CommunicationException ce)
            {
                Console.WriteLine("Wystapil wyjatek: {0}", ce.Message);
                mojHost1.Abort();
                mojHost2.Abort();
                mojHost3.Abort();
                Console.WriteLine("--->Nacisnij <ENTER> aby zakonczyc.\n");
            }
        }
    }
}
