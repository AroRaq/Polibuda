﻿using System.Runtime.Serialization;
using System.ServiceModel;

namespace WcfServiceContract
{
    [ServiceContract]
    public interface IKalkulatorLZ
    {
        [OperationContract]
        LiczbaZ DodajLZ(LiczbaZ n1, LiczbaZ n2);
    }

    [DataContract]
    public class LiczbaZ
    {
        string opis = "Liczba zespolona";
        [DataMember]
        public double czescR;
        [DataMember]
        public double czescU;
        [DataMember]
        public string Opis
        {
            get { return opis; }
            set { opis = value; }
        }
        public LiczbaZ(double czesc_rz, double czesc_ur)
        {
            this.czescR = czesc_rz;
            this.czescU = czesc_ur;
        }
    }

    [ServiceContract]
    public interface IOWSerwis
    {
        [OperationContract(IsOneWay = true)]
        void Funkcja1(string s1);
        [OperationContract]
        void Funkcja2(string s2);
    }

}
