﻿using System;
using System.ServiceModel;
using System.Threading;

namespace WcfServiceContract
{
    public class KalkulatorLZ : IKalkulatorLZ
    {
        public LiczbaZ DodajLZ(LiczbaZ n1, LiczbaZ n2)
        {
            Console.WriteLine("...wywolano DodajLZ(...)");
            return new LiczbaZ(n1.czescR + n2.czescR,
            n1.czescU + n2.czescU);
        }
    }

    [ServiceBehavior(ConcurrencyMode = ConcurrencyMode.Multiple)]
    public class MojSerwis2 : IOWSerwis
    {
        public void Funkcja1(String s1)
        {
            Console.WriteLine("...{0}: funkcja1 - start", s1);
            Thread.Sleep(4 * 1000); // tu 4 sekundy (40000 ms)
            Console.WriteLine("...{0}” funkcja1 - stop", s1);
            return;
        }
        public void Funkcja2(String s2)
        {
            Console.WriteLine("...{0}: funkcja2 - start", s2);
            Thread.Sleep(2 * 1000); // tu 2 sekundy
            Console.WriteLine("...{0}: funkcja2 - stop", s2);
            return;
        }
    }
}
