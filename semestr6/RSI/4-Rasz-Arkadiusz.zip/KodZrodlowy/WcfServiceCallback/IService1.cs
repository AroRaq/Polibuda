﻿using System.ServiceModel;
using System.Runtime.Serialization;
using System.Collections.Generic;

namespace WcfServiceCallback
{
  [ServiceContract(SessionMode = SessionMode.Required, CallbackContract = typeof(ICallbackHandler))]
  public interface IBiblioteka
  {
    [OperationContract]
    void DodajKsiazke(string tytul, string autor, long ISBN, int rokWydania, double cena);

    [OperationContract]
    Ksiazka SzukajPoISBN(long ISBN);

    [OperationContract]
    Ksiazka SzukajPoTytule(string tytul);

    [OperationContract]
    bool ModyfikujTytul(long ISBN, string nowyTytul);

    [OperationContract]
    List<string> PobierzOpisy();

    [OperationContract]
    double AktualnaWartoscWszystkichKsiazek();

    [OperationContract(IsOneWay = true)]
    void PobierzKsiazki();

    [OperationContract]
    string Info();
  }

  [DataContract]
  public class Ksiazka
  {
    string tytul;

    [DataMember]
    public string autor;

    [DataMember]
    public long ISBN;

    [DataMember]
    public int rokWydania;

    [DataMember]
    public double cena;

    [DataMember]
    public string Tytul
    {
      get { return tytul; }
      set { tytul = value; }
    }

    public Ksiazka(string tytul, string autor, long ISBN, int rokWydania, double cena)
    {
      this.tytul = tytul;
      this.autor = autor;
      this.ISBN = ISBN;
      this.rokWydania = rokWydania;
      this.cena = cena;
    }

    public override string ToString()
    {
      return $"Tytul: {tytul}, Autor: {autor}, ISBN: {ISBN}, Rok wydania: {rokWydania}, Cena: {cena}";
    }
  }

  public interface ICallbackHandler
  {
    [OperationContract(IsOneWay = true)]
    void ZwrotPobierzKsiazki(List<Ksiazka> result);
  }
}
