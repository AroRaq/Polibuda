﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Threading;

namespace WcfServiceCallback
{

  [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerSession, ConcurrencyMode = ConcurrencyMode.Multiple)]
  public class MojaBiblioteka : IBiblioteka
  {
    ICallbackHandler callback = null;
    List<Ksiazka> ksiazki = new List<Ksiazka>();
    DateTime? ostatinieWywolanieCallback = null;

    public MojaBiblioteka()
    {
      callback = OperationContext.Current.GetCallbackChannel<ICallbackHandler>();
    }

    public double AktualnaWartoscWszystkichKsiazek()
    {
      double sum = ksiazki.Sum(k => k.cena);
      return sum;
    }

    public void DodajKsiazke(string tytul, string autor, long ISBN, int rokWydania, double cena)
    {
      var ksiazka = new Ksiazka(tytul, autor, ISBN, rokWydania, cena);
      ksiazki.Add(ksiazka);
    }

    public string Info()
    {
      var ostCallback = ostatinieWywolanieCallback != null 
        ? ostatinieWywolanieCallback.ToString() 
        : "brak";

      return $@"
Autorzy: Arkadiusz Rasz 242493
           Karol Szałajko 242557
Data: {DateTime.Now} 
Ostatni callback: {ostCallback}";
    }

    public bool ModyfikujTytul(long ISBN, string nowyTytul)
    {
      Ksiazka doModyfikacji = ksiazki.FirstOrDefault(k => k.ISBN == ISBN);
      if (doModyfikacji == null) return false;
      doModyfikacji.Tytul = nowyTytul;
      return true;
    }

    public void PobierzKsiazki()
    {
      Thread.Sleep(12 * 1000); //12s
      ostatinieWywolanieCallback = DateTime.Now;
      callback.ZwrotPobierzKsiazki(ksiazki);
    }

    public List<string> PobierzOpisy()
    {
      List<string> opisy = ksiazki
        .Select(k => $"Tytuł: {k.Tytul}, Autor: {k.autor}")
        .ToList();
      return opisy;
    }

    public Ksiazka SzukajPoISBN(long ISBN)
    {
      return ksiazki.FirstOrDefault(k => k.ISBN == ISBN);
    }

    public Ksiazka SzukajPoTytule(string tytul)
    {
      return ksiazki.FirstOrDefault(k => k.Tytul.StartsWith(tytul));
    }
  }
}
