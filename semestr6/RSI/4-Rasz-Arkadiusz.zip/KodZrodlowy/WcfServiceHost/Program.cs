﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using WcfServiceCallback;

namespace WcfServiceHost
{
  class Program
  {
    static void Main(string[] args)
    {
      Uri baseAddress = new Uri("http://localhost:30018/service");
      ServiceHost mojHost = new ServiceHost(typeof(MojaBiblioteka), baseAddress);
      try
      {
        ServiceMetadataBehavior smb = new ServiceMetadataBehavior();
        smb.HttpGetEnabled = true;

        ServiceEndpoint endpoint3 = mojHost.AddServiceEndpoint(
          typeof(IBiblioteka),
          new WSDualHttpBinding(),
         "CallbackBiblioteka");
        mojHost.Description.Behaviors.Add(smb);
        mojHost.Open();
        Console.WriteLine("--->CallbackBiblioteka uruchomiony.");

        Console.WriteLine("--->Nacisnij <ENTER> aby zakonczyc.\n");
        Console.ReadLine(); //czekam na zamkniecie
        mojHost.Close();
        Console.WriteLine("---> Serwis zakonczyl dzialanie.");
      }
      catch (CommunicationException ce)
      {
        Console.WriteLine("Wystapil wyjatek: {0}", ce.Message);
        mojHost.Abort();
        Console.WriteLine("--->Nacisnij <ENTER> aby zakonczyc.\n");
      }
    }
  }
}
