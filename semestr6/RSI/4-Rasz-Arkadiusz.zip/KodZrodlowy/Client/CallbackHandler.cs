﻿using Client.BibliotekaReference;
using System;
using System.Linq;

namespace Client
{
  class CallbackHandler : IBibliotekaCallback
  {
    private MainWindow _window;

    public CallbackHandler(MainWindow window)
    {
      _window = window;
    }

    public void ZwrotPobierzKsiazki(Ksiazka[] result)
    {
      _window.Log += "Otrzymano informację zwrotną z książkami\n";
      result.ToList().ForEach(k => Console.WriteLine(k));
      _window.Ksiazki = string.Join("\n", result.Select(k => 
      $"{k.autor}: {k.Tytul}, {k.rokWydania}, ISBN:{k.ISBN}, cena:{k.cena}\n"));
    }
  }
}
