﻿using Client.BibliotekaReference;
using System;
using System.ComponentModel;
using System.ServiceModel;
using System.Windows;

namespace Client
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window, INotifyPropertyChanged
  {
    public MainWindow()
    {
      InitializeComponent();
      DataContext = this;
      _handler = new CallbackHandler(this);
      _instanceContext = new InstanceContext(_handler);
      _client = new BibliotekaClient(_instanceContext);

      DodajDane();
      Log += _client.Info() + '\n';
      PobierzKsiazki();

    }

    void DodajDane()
    {
      _client.DodajKsiazke("Harry Potter and the Sorcerer's Stone", "J.K. Rowling", 9780439554930, 1997, 34);
      _client.DodajKsiazke("Checkmate", "Dorothy Dunnett", 1327612878781, 1997, 23);
      _client.DodajKsiazke("A Song of Ice and Fire", "George R. R. Martin", 3647812873616, 1996, 12);
    }

    void PobierzKsiazki()
    {
      Log += "Pobieranie książek....\n";
      _client.PobierzKsiazki();
    }

    private InstanceContext _instanceContext;
    private BibliotekaClient _client;
    private CallbackHandler _handler;

    private string _tytul;
    private string _autor;
    private string _cena;
    private string _rokWydania;
    private string _isbn;

    private string _isbnSzukaj;
    private string _tytulSzukaj;

    private string _isbnModify;
    private string _tytulModify;

    private string _ksiazki;

    private string _wartoscKsiazek;

    private string _log;

    public string Tytul
    {
      get => _autor;
      set => _autor = value;
    }
    public string Autor
    {
      get => _tytul;
      set => _tytul = value;
    }
    public string Cena
    {
      get => _cena;
      set => _cena = value;
    }
    public string RokWydania
    {
      get => _rokWydania;
      set => _rokWydania = value;
    }
    public string ISBN
    {
      get => _isbn;
      set => _isbn = value;
    }

    public string ISBNSzukaj
    {
      get => _isbnSzukaj;
      set => _isbnSzukaj = value;
    }

    public string TytulSzukaj
    {
      get => _tytulSzukaj;
      set => _tytulSzukaj = value;
    }

    public string ISBNModify
    {
      get => _isbnModify;
      set => _isbnModify = value;
    }

    public string TytulModify
    {
      get => _tytulModify;
      set => _tytulModify = value;
    }

    public string Log
    {
      get => _log;
      set
      {
        _log = value;
        OnPropertyChanged("Log");
      }
    }

    public string Ksiazki
    {
      get => _ksiazki;
      set
      {
        _ksiazki = value;
        OnPropertyChanged("Ksiazki");
      }
    }

    public string WartoscKsiazek
    {
      get => _wartoscKsiazek;
      set
      {
        _wartoscKsiazek = value;
        OnPropertyChanged("WartoscKsiazek");
      }
    }

    private void DodajKsiazke_Click(object sender, RoutedEventArgs e)
    {
      try
      {
        var cena = int.Parse(Cena);
        var isbn = long.Parse(ISBN);
        var rokWydania = int.Parse(RokWydania);
        _client.DodajKsiazke(Tytul, Autor, isbn, rokWydania, cena);
        Log += $"Dodano ksiazke\n";
        PobierzKsiazki();
      }
      catch (ArgumentNullException)
      {
        Log += "Prosze podać wszystkie dane książki!\n";
      }
      catch (FormatException)
      {
        Log += "Prosze podac poprawne dane!\n";
      }
    }




    public event PropertyChangedEventHandler PropertyChanged;
    private void OnPropertyChanged(string propertyName)
    {
      PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }

    private void PobierzAktualnaWartosc_Click(object sender, RoutedEventArgs e)
    {
      var wartosc = _client.AktualnaWartoscWszystkichKsiazek();
      WartoscKsiazek = $"{wartosc} zł";
    }

    private void SzukajISBN_Click(object sender, RoutedEventArgs e)
    {
      if (ISBNSzukaj == null)
      {
        Log += "Prosze podać ISBN!\n";
        return;
      }
      try
      {
        var isbn = long.Parse(ISBNSzukaj);
        var ksiazka = _client.SzukajPoISBN(isbn);
        if (ksiazka == null)
          Log += "Nie znaleziono książki.\n";
        else
          Log += $"Znaleziono książkę:\n{ksiazka.autor}: {ksiazka.Tytul}\n";
      }
      catch (FormatException)
      {
        Log += "Prosze podac poprawne dane!\n";
      }
    }

    private void SzukajTytul_Click(object sender, RoutedEventArgs e)
    {
      if (TytulSzukaj == null)
      {
        Log += "Prosze podać tytuł!\n";
        return;
      }
      var ksiazka = _client.SzukajPoTytule(TytulSzukaj);
      if (ksiazka == null)
        Log += "Nie znaleziono książki.\n";
      else
        Log += $"Znaleziono książkę:\n{ksiazka.autor}: {ksiazka.Tytul}\n";
    }

    private void ModyfikujKsiazke_Click(object sender, RoutedEventArgs e)
    {
      if (ISBNModify == null)
      {
        Log += "Prosze podać ISBN!\n";
        return;
      }
      if (TytulModify == null)
      {
        Log += "Prosze podać nowy tytuł!\n";
        return;
      }
      try
      {
        var isbn = long.Parse(ISBNModify);
        var success = _client.ModyfikujTytul(isbn, TytulModify);
        if (success)
          Log += "Pomyślnie zmodyfikowano tytuł.\n";
        else
          Log += $"Nie odnaleziono książki o ISBN {isbn}";
      }
      catch (FormatException)
      {
        Log += "Prosze podac poprawne dane!\n";
      }

    }

    private void AktualizujKsiazki_Clik(object sender, RoutedEventArgs e)
    {
      PobierzKsiazki();
    }

    private void PobierzInfo_Click(object sender, RoutedEventArgs e)
    {
      Log += _client.Info() + '\n';
    }
  }
}
