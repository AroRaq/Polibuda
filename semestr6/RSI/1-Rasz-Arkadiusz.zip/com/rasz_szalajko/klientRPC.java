package com.rasz_szalajko;

import org.apache.xmlrpc.AsyncCallback;
import org.apache.xmlrpc.XmlRpcClient;
import org.apache.xmlrpc.XmlRpcException;

import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

public class klientRPC {

    private static Scanner _scanner = new Scanner(System.in);
    private static XmlRpcClient _client;
    private static String _serverName;

    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in);
            System.out.println("Podaj adres serwera:");
            String url = scanner.next();
            System.out.println("Podaj port:");
            int port = scanner.nextInt();
            System.out.println("Podaj nazwe serwera:");
            _serverName = scanner.next();
            _client = new XmlRpcClient(url + ":" + port);
            String command = "";
            onShow();
            do {
                System.out.println("Wprowadz komende:");
                command = scanner.next();
                onCommand(command);
            }
            while (!command.equals("exit"));
            System.out.println("Zakonczono dzialanie programu.");
        } catch (XmlRpcException | IOException e) {
            e.printStackTrace();
        }
    }

    private static void onCommand(String command) throws XmlRpcException, IOException {
        switch (command) {
            case "intCalculate":
                onIntCalculate();
                break;
            case "myHello":
                onMyHello();
                break;
            case "maxPrime":
                onMaxPrime();
                break;
            case "show":
                onShow();
                break;
            case "exit":
                break;
            default:
                onShow();
                break;
        }
    }

    private static void onIntCalculate() throws XmlRpcException, IOException {
        Vector<Object> params = new Vector<>();
        System.out.println("Podaj pierwsza liczbe:");
        params.add(_scanner.nextInt());
        System.out.println("Podaj druga liczbe:");
        params.add(_scanner.nextInt());
        System.out.println("Podaj operatory:");
        params.add(_scanner.next());
        System.out.println(_client.execute(_serverName + ".intCalculate", params));
    }

    private static void onMyHello() throws XmlRpcException, IOException {
        Vector<Object> params = new Vector<>();
        System.out.println("Podaj imie:");
        params.add(_scanner.next());
        System.out.println("Podaj kod lokalny:");
        params.add(_scanner.next());
        System.out.println(_client.execute(_serverName + ".myHello", params));
    }

    private static void onMaxPrime() {
        Vector<Object> params = new Vector<>();
        System.out.println("Podaj opoznienie:");
        params.add(_scanner.nextInt());
        System.out.println("Podaj dolne ograniczenie:");
        params.add(_scanner.nextInt());
        System.out.println("Podaj gorne ograniczenie:");
        params.add(_scanner.nextInt());
        _client.executeAsync(_serverName + ".maxPrime", params, new AC());
    }

    private static void onShow() throws XmlRpcException, IOException {
        Vector<Object> params = new Vector<>();
        System.out.println("Dostepne komendy to:");
        System.out.println(_client.execute(_serverName + ".show", params));
    }
}

