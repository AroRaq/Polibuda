package com.rasz_szalajko;

import org.apache.xmlrpc.AsyncCallback;

import java.net.URL;

public class AC implements AsyncCallback {

    public void handleResult(Object object, URL url, String method) {
        System.out.println(
                "Url: " + url + '\n' +
                "Metoda: " + method + '\n' +
                "Wynik: " + object + '\n');

    }

    @Override
    public void handleError(Exception e, URL url, String method) {
        System.out.println(
                "Url: " + url + '\n' +
                "Metoda: " + method + '\n' +
                "Blad: " + e + '\n');
    }
}
