package com.rasz_szalajko;

import org.apache.xmlrpc.WebServer;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class serwerRPC {

    public static void main(String[] args) {

        try {
            System.out.println("Starting server XML-RPC...");
            int port = 10009;
            WebServer server = new WebServer(port);
            server.addHandler("MyServer", new serwerRPC());
            server.start();
            System.out.println("Server started successfully. Listening on port: " + port);
            System.out.println("To stop the server, press ctrl+c.");

        }
        catch (Exception exception) {
            System.err.println("Exception occurred: " + exception);
        }
    }

    public String intCalculate(int a, int b, String ops) {
        StringBuilder stringBuilder = new StringBuilder();
        for (char c : ops.toCharArray()) {
            switch (c) {
                case '+': stringBuilder.append(a + " + " + b + " = " + (a+b) + '\n'); break;
                case '-': stringBuilder.append(a + " - " + b + " = " + (a-b) + '\n'); break;
                case '*': stringBuilder.append(a + " * " + b + " = " + (a*b) + '\n'); break;
                case '/':  {
                    if (b != 0)
                        stringBuilder.append(a + " / " + b + " = " + (a/b) + '\n');
                    else
                        stringBuilder.append(a + " / " + b + " - operacja niedozwolona (dzielenie przez 0) " + '\n');
                    break;
                }
            }
        }
        return stringBuilder.toString();
    }

    public String myHello(String name, String locale) {
        String result = "Hello " + name + '\n';
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE, dd-MMM-YYYY HH:mm", new Locale(locale));
        result += dateFormat.format(new Date());
        return result;
    }

    public int maxPrime(int delay, int value1, int value2) {
        int result = -1;
        for (int i = value2; i >= value1; i--) {
            if (isPrime(i)) {
                result = i;
                break;
            }
        }
        try {
            Thread.sleep(delay * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return result;
    }

    private boolean isPrime(int val) {
        if (val % 2 == 0) return false;
        for (int i = 3; i <= Math.sqrt(val); i+=2) {
            if (val % i == 0) return false;
        }
        return true;
    }

    public String show() {
        return
                "intCalculate(int num1, int num2, String operators) \n" +
                "       - Oblicza dzialanie na dwoch liczbach. Wiele operatorow moze byc podanych na raz. Wspierane sa operatory +, -, * oraz /.\n\n" +
                "myHello(String name, String locale) \n" +
                "       - Wypisuje przywitanie oraz aktualny czas w podanym jezyku. \n\n" +
                "maxPrime(int delayInSeconds, int min, int max) \n" +
                "       - Zwraca najwieksza liczbe pierwsza w podanym przedziale po podanym opoznieniu w sekundach \n\n";

    }
}
