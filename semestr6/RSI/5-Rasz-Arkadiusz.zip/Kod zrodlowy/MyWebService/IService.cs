﻿using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace MyWebService
{
  [ServiceContract]
  public interface IRestService
  {
    [OperationContract]
    [WebGet(UriTemplate = "/books", ResponseFormat = WebMessageFormat.Xml)]
    List<Book> GetAll();

    [OperationContract]
    [WebGet(UriTemplate = "/books/{id}", ResponseFormat = WebMessageFormat.Xml)]
    Book GetById(string id);

    [OperationContract]
    [WebInvoke(UriTemplate = "/books", Method = "POST", RequestFormat = WebMessageFormat.Xml)]
    string Add(Book element);

    [OperationContract]
    [WebInvoke(UriTemplate = "/books/{id}", Method = "DELETE", ResponseFormat = WebMessageFormat.Xml)]
    string Delete(string id);

    [OperationContract]
    [WebInvoke(UriTemplate = "/books", Method = "PATCH", RequestFormat = WebMessageFormat.Xml)]
    string Modify(Book element);

    [OperationContract]
    [WebInvoke(UriTemplate = "/info", Method = "GET")]
    string Info();



    [OperationContract]
    [WebGet(UriTemplate = "/json/books", ResponseFormat = WebMessageFormat.Json)]
    List<Book> GetJsonAll();

    [OperationContract]
    [WebGet(UriTemplate = "/json/books/{id}", ResponseFormat = WebMessageFormat.Json)]
    Book GetJsonById(string id);

    [OperationContract]
    [WebInvoke(UriTemplate = "/json/books", Method = "POST", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
    string AddJson(Book element);

    [OperationContract]
    [WebInvoke(UriTemplate = "/json/books/{id}", Method = "DELETE", ResponseFormat = WebMessageFormat.Json)]
    string DeleteJson(string id);

    [OperationContract]
    [WebInvoke(UriTemplate = "/json/books", Method = "PATCH", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json)]
    string ModifyJson(Book element);

    [OperationContract]
    [WebInvoke(UriTemplate = "/json/info", Method = "GET", ResponseFormat = WebMessageFormat.Json)]
    string InfoJson();
  }
}
