﻿using System.Runtime.Serialization;

namespace MyWebService
{
  [DataContract]
  public class Book
  {
    [DataMember]
    public int Id;

    [DataMember]
    public string Title;

    [DataMember]
    public string Author;

    [DataMember]
    public long ISBN;

    [DataMember]
    public int ReleaseYear;

    [DataMember]
    public double Price;

    public Book(int id, string title, string author, long isbn, int releaseYear, double price)
    {
      Id = id;
      Title = title;
      Author = author;
      ISBN = isbn;
      ReleaseYear = releaseYear;
      Price = price;
    }

    public override string ToString()
    {
      return $"Tytul: {Title}, Autor: {Author}, ISBN: {ISBN}, Rok wydania: {ReleaseYear}, Cena: {Price}";
    }
  }
}
