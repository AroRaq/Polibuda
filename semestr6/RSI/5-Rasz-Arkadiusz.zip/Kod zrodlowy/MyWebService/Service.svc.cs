﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text.RegularExpressions;

namespace MyWebService
{
  [ServiceBehavior(InstanceContextMode = InstanceContextMode.Single)]
  public class RestService : IRestService
  {
    private static List<Book> books;

    private readonly Regex authorRegex = new Regex(@"/[A-Z][\w\d]{2,}\ [A-Z][\w\d]{2,}/g");

    public RestService()
    {
      books = new List<Book> 
      {
        new Book(0, "Ostatnie Historie", "Olga Tokarczuk", 9780439554930, 2004, 34),
        new Book(1, "Checkmate", "Dorothy Dunnett", 1327612878781, 1997, 23),
        new Book(2, "The Tale of Genji", "Murasaki Shikibu", 3647812873616, 2003, 12),
      };
    }

    public string Add(Book book)
    {
      if (book == null)
        throw new WebFaultException<string>("Proszę podać książkę w poprawnym formacie", HttpStatusCode.BadRequest);

      if (books.Any(b => b.Id == book.Id))
        throw new WebFaultException<string>($"Książka o id=[{book.Id}] już istnieje", HttpStatusCode.Conflict);

      if (ValidateAuthor(book.Author))
        throw new WebFaultException<string>($"Autor nie jest w poprawnym formacie", HttpStatusCode.BadRequest);

      books.Add(book);
      return $"Dodano książkę z id=[{book.Id}]";
    }

    public string Delete(string id)
    {
      if (int.TryParse(id, out int intId) == false)
        throw new WebFaultException<string>($"Id [{id}] musi być liczbą", HttpStatusCode.BadRequest);

      var removedCount = books.RemoveAll(b => b.Id == intId);
      if (removedCount == 0)
        throw new WebFaultException<string>($"Nie znaleziono książki o id=[{id}]", HttpStatusCode.NotFound);

      return $"Usunięto książkę z id=[{id}]";
    }

    public List<Book> GetAll()
    {
      return books;
    }

    public Book GetById(string id)
    {
      if (int.TryParse(id, out int intId) == false)
        throw new WebFaultException<string>($"Id [{id}] musi być liczbą", HttpStatusCode.BadRequest);

      var book = books.SingleOrDefault(b => b.Id == intId);
      if (book == null)
        throw new WebFaultException<string>($"Nie znaleziono książki o id=[{id}]", HttpStatusCode.NotFound);

      return book;
    }

    public string Info()
    {
      return $@"
Autorzy:   Arkadiusz Rasz 242493
           Karol Szałajko 242557
Data: {DateTime.Now}";
    }

    public string Modify(Book book)
    {
      if (book == null)
        throw new WebFaultException<string>("Proszę podać książkę w poprawnym formacie", HttpStatusCode.BadRequest);

      var bookToModify = books.SingleOrDefault(b => b.Id == book.Id);
      if (bookToModify == null)
        throw new WebFaultException<string>($"Nie znaleziono książki o id=[{book.Id}]", HttpStatusCode.NotFound);

      bookToModify.ISBN = book.ISBN;
      bookToModify.Price = book.Price;
      bookToModify.ReleaseYear = book.ReleaseYear;
      bookToModify.Title = book.Title;
      return $"Zmodyfikowano książkę z id=[{book.Id}]";
    }


    public List<Book> GetJsonAll() => GetAll();
    public Book GetJsonById(string id) => GetById(id);
    public string AddJson(Book element) => Add(element);
    public string DeleteJson(string id) => Delete(id);
    public string InfoJson() => Info();
    public string ModifyJson(Book element) => Modify(element);




    private bool ValidateAuthor(string author)
    {
      return authorRegex.Match(author).Success;
    }

  }
}
