﻿using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace TextClassifier
{
  class Program
  {
    static void Main(string[] args)
    {
      ParseDataToARFF();
      // ParseDataToCsv();
      // Program2.Main1(new string[] { });
    }

    static void ParseDataToARFF()
    {

      var filePaths = Directory.GetFiles(@"C:\dev\TextClassifier\all_data");
      // var filePaths = Directory.GetFiles(@"C:\dev\TextClassifier\wiki_test_34_categories_data");
      // var filePaths = Directory.GetFiles(@"C:\dev\TextClassifier\wiki_train_34_categories_data");
      var fileBuilder = new StringBuilder();

      var charsToRemove = ",./;':\"[]{}\\|!@#$%^&*()<>?"
        .Select(c => c.ToString()).ToList();
      var regex = new Regex("[ ]{2,}", RegexOptions.None);

      fileBuilder.AppendLine("@RELATION wiki");

      var lastLabel = string.Empty;
      var labels = new List<string>();
      foreach (var path in filePaths)
      {
        var fileName = Path.GetFileName(path);
        var label = fileName.Split('_')[0];
        if (label != lastLabel)
          labels.Add(label);
        lastLabel = label;
      }

      fileBuilder.AppendLine($"@ATTRIBUTE class {{{string.Join(", ", labels)}}}");

      fileBuilder.AppendLine("@ATTRIBUTE text STRING");
      fileBuilder.AppendLine("@DATA");

      foreach (var path in filePaths)
      {
        var fileName = Path.GetFileName(path);
        var label = fileName.Split('_')[0];
        var content = File.ReadAllLines(path);
        var singleLine = string.Join(' ', content);
        charsToRemove.ForEach(c => singleLine = singleLine.Replace(c, string.Empty));
        singleLine = singleLine.Replace("\t", string.Empty);
        singleLine = regex.Replace(singleLine, " ");
        singleLine = singleLine.Trim();
        fileBuilder.AppendLine($"{label},'{singleLine}'");
        // csvBuilder.Append($"{label}\t{singleLine}");
        // csvBuilder.AppendLine();
      }

      // File.WriteAllText(@"C:\dev\TextClassifier\train_data.arff", fileBuilder.ToString(), Encoding.UTF8);
      // File.WriteAllText(@"C:\dev\TextClassifier\test_data.arff", fileBuilder.ToString(), Encoding.UTF8);
      File.WriteAllText(@"C:\dev\TextClassifier\data.arff", fileBuilder.ToString(), Encoding.UTF8);
    }

    static void ParseDataToCsv()
    {
      // var filePaths = Directory.GetFiles(@"C:\dev\TextClassifier\wiki_test_34_categories_data");
      var filePaths = Directory.GetFiles(@"C:\dev\TextClassifier\wiki_train_34_categories_data");
      var csvBuilder = new StringBuilder();

      var charsToRemove = ",./;':\"[]{}\\|!@#$%^&*()<>?".Select(c => c.ToString()).ToList();
      var regex = new Regex("[ ]{2,}", RegexOptions.None);

      csvBuilder.Append("Class\tContentText");
      csvBuilder.AppendLine();
      foreach (var path in filePaths)
      {
        var fileName = Path.GetFileName(path);
        var label = fileName.Split('_')[0];
        var content = File.ReadAllLines(path);
        var singleLine = string.Join(' ', content);
        charsToRemove.ForEach(c => singleLine = singleLine.Replace(c, string.Empty));
        singleLine = singleLine.Replace("\t", string.Empty);
        singleLine = regex.Replace(singleLine, " ");
        singleLine = singleLine.Trim();
        csvBuilder.Append($"{label}\t{singleLine}");
        csvBuilder.AppendLine();
      }

      // File.WriteAllText(@"C:\dev\TextClassifier\test_data.tsv", csvBuilder.ToString(), Encoding.Unicode);
      File.WriteAllText(@"C:\dev\TextClassifier\train_data.tsv", csvBuilder.ToString(), Encoding.Unicode);
    }
  }
}
