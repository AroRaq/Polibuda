package com.arkadr;

import weka.classifiers.Evaluation;
import weka.classifiers.trees.RandomForest;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;
import weka.filters.Filter;
import weka.filters.unsupervised.attribute.StringToWordVector;

import java.util.Random;

public class Main {

    public static void main(String[] args) {
        try {
            var startTime = System.nanoTime();

            var trainDataSource = new DataSource("C:\\dev\\si\\data.arff");
            var trainData = trainDataSource.getDataSet();
            trainData.setClassIndex(0);

            trainData = PreProcessData(trainData);

            var evaluation = new Evaluation(trainData);
//            evaluation.crossValidateModel(new J48(), trainData, 5, new Random(1));
            evaluation.crossValidateModel(new RandomForest() , trainData, 2, new Random(1));
            System.out.println(evaluation.toSummaryString());
            System.out.println(evaluation.toClassDetailsString());
            var endTime = System.nanoTime();
            System.out.println("Finished in: " + String.format("%.2f", (endTime - startTime)/1000000000.) + " seconds" );
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Instances PreProcessData(Instances data) throws Exception {

        var stringToWordVector = new StringToWordVector();
        stringToWordVector.setInputFormat(data);
        stringToWordVector.setLowerCaseTokens(false);
        stringToWordVector.setMinTermFreq(1);
        stringToWordVector.setWordsToKeep(5000);
        stringToWordVector.setOutputWordCounts(true);
        stringToWordVector.setIDFTransform(true);
        stringToWordVector.setTFTransform(false);
//        stringToWordVector.setStemmer(new weka.core.stemmers.Stemming());
        data = Filter.useFilter(data, stringToWordVector);

//        var removeUseless = new RemoveUseless();
//        removeUseless.setMaximumVariancePercentageAllowed(0.1);
//        removeUseless.setInputFormat(data);
//        data = Filter.useFilter(data, removeUseless);
//
//        var fixMissing = new ReplaceMissingValues();
//        fixMissing.setInputFormat(data);
//        data = Filter.useFilter(data, fixMissing);

        return data;
    }
}
