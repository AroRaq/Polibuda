#pragma once

#include <string>
#include <sstream>
#include <fstream>
#include "Creature.h"

class RunData {
public:
	RunData(std::string problemName);
	void AddGenerationResult(int gen, long double best, long double avg, long double worst);
	void SaveToFile(std::string path);
	void SaveBestCreature(Creature* creature);

private:
	std::stringstream _stringBuilder;
	std::string _problemName;
	Creature* _bestCreature;
};

