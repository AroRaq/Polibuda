#include "SwapMutator.h"

void SwapMutator::Mutate(Creature* creature) {
	int len = creature->GetGenotypeLength();
	for (int i = 0; i < len; i++) {
		if (!Utils::Chance(this->_mutationChance))
			return;

		int pos1 = Utils::RandInt(0, len - 1);
		int pos2 = (Utils::RandInt(0, len - 2) + pos1 + 1) % len;
		std::swap(creature->GeneAt(pos1), creature->GeneAt(pos2));
	}
};