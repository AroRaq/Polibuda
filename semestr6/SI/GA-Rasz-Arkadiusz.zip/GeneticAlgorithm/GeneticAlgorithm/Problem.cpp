#include "Problem.h"

Problem::Problem(std::string name, int size, long double optimalSolution, PointProvider* pointProvider)
{
	this->_name = name;
	this->_size = size;
	this->_optimalSolution = optimalSolution;
	this->_pointProvider = pointProvider;
	this->_fitnessCalculator = new FitnessCalculator(pointProvider);
}

Problem::~Problem()
{
	delete this->_fitnessCalculator;
	delete this->_pointProvider;
}

int Problem::GetSize()
{
	return _size;
}

long double Problem::Evaluate(Creature* creature)
{
	return this->_fitnessCalculator->Evaluate(creature);
}

std::string Problem::GetName()
{
	return _name;
}

PointProvider* Problem::GetPointProvider()
{
	return _pointProvider;
}
