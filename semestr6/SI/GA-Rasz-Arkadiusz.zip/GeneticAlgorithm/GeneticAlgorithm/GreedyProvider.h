#pragma once

#include "ICreatureProvider.h"
#include "PointProvider.h"

class GreedyProvider : public ICreatureProvider
{
public:
	GreedyProvider(PointProvider* pointProvider);
	Creature* GenerateCreature(Creature* left, Creature* right) override;

private:
	PointProvider* _pointProvider;
	int _currStartingPoint = 0;
};

