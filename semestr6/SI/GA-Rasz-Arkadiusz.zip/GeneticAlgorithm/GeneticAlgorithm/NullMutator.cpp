#include "NullMutator.h"

NullMutator::NullMutator() : IMutator(0) { }

void NullMutator::Mutate(Creature* creature) { return; }
