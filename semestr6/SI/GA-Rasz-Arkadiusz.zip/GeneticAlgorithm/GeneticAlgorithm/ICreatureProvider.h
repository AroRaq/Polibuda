#pragma once

#include "Creature.h"

class ICreatureProvider {
public:
	ICreatureProvider(double crossoverChance);
	virtual Creature* GenerateCreature(Creature* left, Creature* right) = 0;

protected:
	double _crossoverChance;
};

