#pragma once

#include "IMutator.h"

class NullMutator : public IMutator {
public:
	NullMutator();
	void Mutate(Creature* creature) override;

private:

};

