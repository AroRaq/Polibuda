#pragma once

#include "IParentSelector.h"
#include "Utils.h"

class TourSelector : public IParentSelector {
public:
	TourSelector(int tourSize);
	Creature* GetParent(std::vector<Creature*>* population) override;
	void Reset() override;

private:
	int _tourSize;
};

