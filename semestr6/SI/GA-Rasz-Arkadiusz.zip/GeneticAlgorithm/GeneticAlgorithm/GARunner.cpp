#include "GARunner.h"

GARunner::GARunner(
	Problem* problem,
	int population, 
	int generations,
	IMutator* mutator)
{
	_problem = problem;
	_population = population;
	_generations = generations;
	_mutator = mutator;
	_runData = new RunData(_problem->GetName());
	_randomCreatureProvider = new RandomCreatureProvider(_problem->GetSize());
	GenerateInitialGeneration();
}

GARunner::~GARunner()
{
	for (int i = 0; i < this->_currentGeneration->size(); i++) {
		delete _currentGeneration->at(i);
	};
	delete _currentGeneration;
	delete _mutator;
	delete _runData;
	for (auto crossoverStep : _crossoverSteps) {
		delete crossoverStep->CreatureProvider;
	};
	delete _randomCreatureProvider;
}

void GARunner::Run()
{
	for (int generation = 0; generation < _generations; generation++) {
		
		EvaluateGeneration(generation);

		Cross();

		Mutate();

	};
}

void GARunner::SaveResult(std::string path)
{
	_runData->SaveBestCreature(_bestCreature);
	_runData->SaveToFile(path);
}

void GARunner::AddCrossoverStep(CrossoverStep* step)
{
	_crossoverSteps.push_back(step);
}

void GARunner::GenerateInitialGeneration()
{
	_currentGeneration = new std::vector<Creature*>(_population);
	for (int i = 0; i < _population; i++) {
		_currentGeneration->at(i) = _randomCreatureProvider->GenerateCreature(nullptr, nullptr);
	};
}

void GARunner::EvaluateGeneration(int generation)
{
	long double generationWorst = std::numeric_limits<long double>::max();
	long double generationBest = -std::numeric_limits<long double>::max();
	long double sum = 0;
	for (auto creature : *(this->_currentGeneration)) {
		if (_bestCreature == nullptr) {
			_bestCreature = new Creature(*creature);
		}
		auto fitness = this->_problem->Evaluate(creature);
		if (fitness > generationBest) {
			if (fitness > _bestCreature->Fitness) {
				_bestCreature = new Creature(*creature);
			}
			generationBest = fitness;
		}
		else if (fitness < generationWorst) {
			generationWorst = fitness;
		};
		sum += fitness;
	}
	auto avg = sum / _population;
	std::cout << "Generation " << generation << 
		",\tBest: " << generationBest << 
		",\tAverage: " << avg <<
		",\tWorst: " << generationWorst << "\n";

	_runData->AddGenerationResult(generation, generationBest, avg, generationWorst);
}

void GARunner::Cross()
{
	auto nextGeneration = new std::vector<Creature*>();
	double currShare = 0;
	for (auto crossoverStep : _crossoverSteps) {
		currShare += crossoverStep->Share;
		if (currShare > 1)
			throw std::runtime_error("Reached crossover share > 1");

		while (nextGeneration->size() < currShare * (double)_population) {
			auto leftParent = crossoverStep->ParentSelector->GetParent(_currentGeneration);
			auto rightParent = crossoverStep->ParentSelector->GetParent(_currentGeneration);
			auto child = crossoverStep->CreatureProvider->GenerateCreature(leftParent, rightParent);
			nextGeneration->push_back(child);
		};
		crossoverStep->ParentSelector->Reset();
	};
	while (nextGeneration->size() < _population) {
		nextGeneration->push_back(_randomCreatureProvider->GenerateCreature(nullptr, nullptr));
	};
	for (int i = 0; i < _population; i++) {
		if (_currentGeneration->at(i)->ShouldBeDeleted()) {
			delete _currentGeneration->at(i);
			_currentGeneration->at(i) = nullptr;
		}
		else {
			_currentGeneration->at(i)->Reset();
		}
	}
	delete _currentGeneration;
	_currentGeneration = nextGeneration;
}

void GARunner::Mutate()
{
	for (auto creature : *_currentGeneration) {
		_mutator->Mutate(creature);
	};
}
