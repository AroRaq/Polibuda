#pragma once

#include "ICreatureProvider.h"
#include "IParentSelector.h"

class CrossoverStep {
public:
	CrossoverStep(ICreatureProvider* creatureProvider, IParentSelector* parentSelector, double share);
	~CrossoverStep();
	double Share;
	ICreatureProvider* CreatureProvider;
	IParentSelector* ParentSelector;
};

