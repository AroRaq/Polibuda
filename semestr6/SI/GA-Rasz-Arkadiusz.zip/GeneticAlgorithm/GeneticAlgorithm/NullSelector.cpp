#include "NullSelector.h"

Creature* NullSelector::GetParent(std::vector<Creature*>* population)
{
	return nullptr;
}

void NullSelector::Reset()
{
}
