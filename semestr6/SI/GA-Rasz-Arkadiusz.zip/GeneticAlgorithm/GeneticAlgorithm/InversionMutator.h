#pragma once

#include "IMutator.h"
#include "Utils.h"

class InversionMutator : public IMutator {
public:
	InversionMutator(double mutationChance);
	void Mutate(Creature* creature) override;

private:

};