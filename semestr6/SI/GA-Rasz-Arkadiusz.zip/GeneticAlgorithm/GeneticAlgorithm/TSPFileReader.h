#pragma once

#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include "Problem.h"


class TSPFileReader {
public:
	static Problem* ReadProblemFromFile(std::string path);
private:
	template <typename T>
	static void ReadParameter(std::string line, std::string name, T& out);
};

template<typename T>
inline void TSPFileReader::ReadParameter(std::string line, std::string name, T& out)
{
	return;
}

template<>
inline void TSPFileReader::ReadParameter<std::string>(std::string line, std::string name, std::string& out)
{
	auto found = line.find(name + ": ");
	if (found != std::string::npos) {
		auto param = line.substr(found + name.size() + 2);
		out = param;
	};
}

template<>
inline void TSPFileReader::ReadParameter<int>(std::string line, std::string name, int& out)
{
	auto found = line.find(name + ": ");
	if (found != std::string::npos) {
		auto param = line.substr(found + name.size() + 2);
		out = std::stoi(param);
	};
}

template<>
inline void TSPFileReader::ReadParameter<double>(std::string line, std::string name, double& out)
{
	auto found = line.find(name + ": ");
	if (found != std::string::npos) {
		auto param = line.substr(found + name.size() + 2);
		out = std::stod(param);
	};
}
