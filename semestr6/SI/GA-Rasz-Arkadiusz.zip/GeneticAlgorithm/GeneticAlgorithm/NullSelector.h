#pragma once

#include "IParentSelector.h"

class NullSelector : public IParentSelector
{
public:
	Creature* GetParent(std::vector<Creature*>* population) override;
	void Reset() override;
};

