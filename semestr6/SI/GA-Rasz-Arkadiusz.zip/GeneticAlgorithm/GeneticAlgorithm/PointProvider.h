#pragma once

#include <vector>
#include <cmath>
#include "Point.h"

class PointProvider {
public:
	PointProvider(std::vector<Point*> points);
	~PointProvider();
	long double CalculateDistance(int point1, int point2);
	int GetPointCount();

private:
	std::vector<Point*>* _points;
	std::vector<long double>* _distanceCache;
};