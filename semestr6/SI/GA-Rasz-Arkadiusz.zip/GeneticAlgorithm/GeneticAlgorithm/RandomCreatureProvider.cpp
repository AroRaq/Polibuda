#include "RandomCreatureProvider.h"

RandomCreatureProvider::RandomCreatureProvider(int genotypeLength) : ICreatureProvider(0)
{
	_genotypeLength = genotypeLength;
	_previousGenotype = Utils::Range(0, _genotypeLength);
}

Creature* RandomCreatureProvider::GenerateCreature(Creature* left, Creature* right)
{
	Utils::ShuffleVector(&_previousGenotype);
	return new Creature(_previousGenotype);
}
