#include "Point.h"

Point::Point(long double x, long double y) {
	this->X = x;
	this->Y = y;
}