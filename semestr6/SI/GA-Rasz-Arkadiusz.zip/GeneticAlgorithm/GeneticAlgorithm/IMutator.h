#pragma once
#include "Creature.h"

class IMutator {
public:
	IMutator(double mutationChance);
	virtual void Mutate(Creature* creature) = 0;
protected:
	double _mutationChance;
};