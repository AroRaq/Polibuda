#pragma once

#include <map>
#include "ICreatureProvider.h"
#include "Utils.h"

class CycleCrossoverResultProvider : public ICreatureProvider {
public:
	CycleCrossoverResultProvider(double crossoverChance);
	virtual Creature* GenerateCreature(Creature* left, Creature* right) override;
};

