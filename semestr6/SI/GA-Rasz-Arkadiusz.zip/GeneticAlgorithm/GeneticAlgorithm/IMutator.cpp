#include "IMutator.h"

IMutator::IMutator(double mutationChance)
{
	this->_mutationChance = mutationChance;
}
