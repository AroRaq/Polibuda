#include "RouletteSelector.h"

Creature* RouletteSelector::GetParent(std::vector<Creature*>* population)
{
	if (_population == nullptr) {
		_population = population;
		_popSize = _population->size();
		CalculatePropabilities();
	}

	auto rand = Utils::RandDouble(0, 1);
	for (int i = 0; i < _popSize; i++) {
		if (_propabilities[i] > rand)
			return _population->at(i);
	}
	throw std::runtime_error("Bad props");
}

void RouletteSelector::Reset()
{
	_population = nullptr;
}

void RouletteSelector::CalculatePropabilities()
{
	_propabilities = std::vector<double>();
	long double worst = -std::numeric_limits<long double>::max();
	//long double best = std::numeric_limits<long double>::max();
	long double sum = 0;
	for (auto creature : *_population) {
		if (-creature->Fitness > worst)
			worst = -creature->Fitness;
		//else if (-creature->Fitness < best)
			//best = -creature->Fitness;
	}
	for (auto creature : *_population) {
		sum += MapFitnessValue(0, worst, creature->Fitness);
	}
	double propSum = 0;
	for (auto creature : *_population) {
		propSum += MapFitnessValue(0, worst, creature->Fitness) / sum;
		_propabilities.push_back(propSum);
	}
}

long double RouletteSelector::MapFitnessValue(long double best, long double worst, long double fitnessValue)
{
	return (worst - (-fitnessValue - 1)) * (worst - (-fitnessValue - 1));
}
