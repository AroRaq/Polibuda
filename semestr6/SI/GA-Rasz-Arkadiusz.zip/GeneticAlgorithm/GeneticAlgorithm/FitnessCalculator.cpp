#include "FitnessCalculator.h"

FitnessCalculator::FitnessCalculator(PointProvider* pointProvider)
{
	this->_pointProvider = pointProvider;
}

long double FitnessCalculator::Evaluate(Creature* creature)
{
	long double fitness = 0;
	int length = creature->GetGenotypeLength();
	for (int i = 0; i < length; i++) {
		fitness -= _pointProvider->CalculateDistance(
			creature->GeneAt(i),
			creature->GeneAt(i + 1 == length ? 0 : i + 1)
		);
	};
	creature->Fitness = fitness;
	return fitness;
}
