#pragma once

#include "Creature.h"
#include "PointProvider.h"

class FitnessCalculator {
public:
	FitnessCalculator(PointProvider* pointProvider);
	long double Evaluate(Creature* creature);

private:
	PointProvider* _pointProvider;
};
