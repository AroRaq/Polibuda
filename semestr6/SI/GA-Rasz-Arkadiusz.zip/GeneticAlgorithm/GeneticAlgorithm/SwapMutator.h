#pragma once
#include "IMutator.h"
#include "Utils.h"

class SwapMutator : public IMutator {
public:
	using IMutator::IMutator;
	void Mutate(Creature* creature) override;

private:

};