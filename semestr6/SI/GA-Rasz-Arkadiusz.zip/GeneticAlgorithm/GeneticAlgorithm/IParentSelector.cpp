#include "IParentSelector.h"

//std::vector<Creature*> IParentSelector::SelectNextGeneration()
//{
//	return std::vector<Creature*>();
//}
