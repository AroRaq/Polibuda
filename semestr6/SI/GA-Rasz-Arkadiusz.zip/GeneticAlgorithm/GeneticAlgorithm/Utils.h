#pragma once

#include <random>
#include <iostream>
#include <algorithm>

class Utils {
public:
	static bool Chance(double probability);
	static int RandInt(int from, int to);
	static double RandDouble(double from, double to);
	template <typename T>
	static T RandElement(const std::vector<T>* vec);
	template <typename T>
	static void disposeVector(std::vector<T>* vec);
	template <typename T>
	static void ShuffleVector(std::vector<T>* vec);
	static std::vector<int> Range(int start, int end);

private:
	static std::random_device rd;
	static std::mt19937 gen;
};

template<typename T>
inline T Utils::RandElement(const std::vector<T>* vec)
{
	return vec->at(RandInt(0, (int)vec->size() - 1));
}

template<typename T>
inline void Utils::disposeVector(std::vector<T>* vec)
{
	for (size_t i = 0; i < vec->size(); i++)
		delete vec->at(i);
	delete vec;
}


template<typename T>
inline void Utils::ShuffleVector(std::vector<T>* vec)
{
	std::shuffle(vec->begin(), vec->end(), gen);
}