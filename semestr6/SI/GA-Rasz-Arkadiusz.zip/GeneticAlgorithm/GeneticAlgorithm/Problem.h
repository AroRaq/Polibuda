#pragma once

#include "PointProvider.h"
#include "FitnessCalculator.h"

class Problem {
public:
	Problem(std::string name,int size, long double optimalSolution, PointProvider* pointProvider);
	~Problem();
	int GetSize();
	long double Evaluate(Creature* creature);
	std::string GetName();
	PointProvider* GetPointProvider();

private:
	int _size;
	long double _optimalSolution;
	std::string _name;
	PointProvider* _pointProvider;
	FitnessCalculator* _fitnessCalculator;
};

