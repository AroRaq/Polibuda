#include "GreedyProvider.h"

GreedyProvider::GreedyProvider(PointProvider* pointProvider) : ICreatureProvider(0)
{
	_pointProvider = pointProvider;
}

Creature* GreedyProvider::GenerateCreature(Creature* left, Creature* right)
{
	int pointCount = _pointProvider->GetPointCount();
	std::vector<int> genotype;
	std::vector<bool> visited(pointCount, false);
	genotype.push_back(_currStartingPoint);
	visited[_currStartingPoint] = true;
	for (int genIdx = 1; genIdx < pointCount; genIdx++) {
		auto bestDistance = std::numeric_limits<long double>::max();
		int bestIdx = -1;
		for (int i = 0; i < pointCount; i++) {
			if (visited[i] == false) {
				auto dist = _pointProvider->CalculateDistance(genotype[genIdx - 1], i);
				if (dist < bestDistance) {
					bestDistance = dist;
					bestIdx = i;
				}
			}
		}
		genotype.push_back(bestIdx);
		visited[bestIdx] = true;
	}
	_currStartingPoint++;
	return new Creature(genotype);
}
