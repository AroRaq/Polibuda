#include "RunData.h"
#include <iterator>

RunData::RunData(std::string problemName)
{
	_problemName = problemName;
}

void RunData::AddGenerationResult(int gen, long double best, long double avg, long double worst)
{
	//_stringBuilder << gen << "; " << (long)best << "; " << avg << "; " << (long)worst << "\n";
	_stringBuilder << -(long)best << "; " << -avg << "; " << -(long)worst << "\n";
}

void RunData::SaveToFile(std::string path)
{
	std::ofstream file;
	file.open(path + "_" + _problemName + ".csv", std::ios::out);

	std::ostringstream genotypeStream;
	auto genotype = _bestCreature->GetGenotypeCopy();
	std::copy(genotype.begin(), genotype.end(),
		std::ostream_iterator<int>(genotypeStream, " "));

	file << genotypeStream.str() << "; " << -_bestCreature->Fitness << std::endl;
	file << _stringBuilder.str();
	file.close();
	delete _bestCreature;
}

void RunData::SaveBestCreature(Creature* creature)
{
	_bestCreature = creature;
}
