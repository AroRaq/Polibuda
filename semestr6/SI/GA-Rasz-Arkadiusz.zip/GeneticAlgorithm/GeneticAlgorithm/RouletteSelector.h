#pragma once

#include "IParentSelector.h"
#include "Utils.h"

class RouletteSelector :public IParentSelector
{
public:
	Creature* GetParent(std::vector<Creature*>* population) override;
	void Reset() override;

private:
	void CalculatePropabilities();
	long double MapFitnessValue(long double best, long double worst, long double fitnessValue);
	std::vector<Creature*>* _population;
	int _popSize;
	std::vector<double> _propabilities;
};

