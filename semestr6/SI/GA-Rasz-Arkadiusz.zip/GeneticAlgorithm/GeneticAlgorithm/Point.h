#pragma once

class Point {
public:
	Point(long double x, long double y);
	long double X;
	long double Y;
};