#include "InversionMutator.h"

InversionMutator::InversionMutator(double mutationChance) : IMutator(mutationChance)
{
}

void InversionMutator::Mutate(Creature* creature)
{
	if (!Utils::Chance(this->_mutationChance))
		return;

	int pos1 = Utils::RandInt(0, creature->GetGenotypeLength() - 1);
	int pos2 = (Utils::RandInt(0, creature->GetGenotypeLength() - 2) + pos1 + 1) % creature->GetGenotypeLength();

	if (pos2 < pos1) {
		int temp = pos1;
		pos1 = pos2;
		pos2 = temp;
	}
	for (; pos1 < pos2; pos1++, pos2--) {
		std::swap(creature->GeneAt(pos1), creature->GeneAt(pos2));
	}
}
