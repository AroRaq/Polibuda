#include "PointProvider.h"

PointProvider::PointProvider(std::vector<Point*> points)
{
	_points = new std::vector<Point*>(points);
	_distanceCache = new std::vector<long double>(points.size() * points.size(), -1);
}

PointProvider::~PointProvider()
{
	delete _points;
	delete _distanceCache;
}

long double PointProvider::CalculateDistance(int point1, int point2)
{
	if (_distanceCache->at(point1 * _points->size() + point2) >= 0) {
		return _distanceCache->at(point1 * _points->size() + point2);
	}
	Point* first = this->_points->at(point1);
	Point* second = this->_points->at(point2);
	auto x = first->X - second->X;
	auto y = first->Y - second->Y;
	auto dist = std::sqrt( (x*x)+(y*y) );
	_distanceCache->at(point1 * _points->size() + point2) = dist;
	_distanceCache->at(point2 * _points->size() + point1) = dist;
	return dist;
}

int PointProvider::GetPointCount()
{
	return _points->size();
}
