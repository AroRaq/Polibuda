#include "Creature.h"

Creature::Creature(std::vector<int> genotype)
{
	this->_genotype = new std::vector<int>(genotype);
}

Creature::Creature(Creature& creature)
{
	Fitness = creature.Fitness;
	_genotype = new std::vector<int>(*creature._genotype);
}

Creature::~Creature()
{
	delete this->_genotype;
}

int Creature::GetGenotypeLength()
{
	return this->_genotype->size();
}

int& Creature::GeneAt(int position)
{
	return this->_genotype->at(position);
}

std::vector<int> Creature::GetGenotypeCopy()
{
	return std::vector<int>(*_genotype);
}

void Creature::KeepInstance()
{
	_toDelete = false;
}

void Creature::Reset()
{
	_toDelete = true;
}

bool Creature::ShouldBeDeleted()
{
	return _toDelete;
}
