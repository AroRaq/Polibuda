#include "CrossoverStep.h"

CrossoverStep::CrossoverStep(ICreatureProvider* creatureProvider, IParentSelector* parentSelector, double share)
{
	CreatureProvider = creatureProvider;
	ParentSelector = parentSelector;
	Share = share;
}

CrossoverStep::~CrossoverStep()
{
	delete CreatureProvider;
	delete ParentSelector;
}
