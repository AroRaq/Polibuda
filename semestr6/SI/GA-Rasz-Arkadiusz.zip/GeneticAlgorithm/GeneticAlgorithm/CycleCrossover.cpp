#include "CycleCrossover.h"

Creature* CycleCrossover::Cross(Creature* left, Creature* right)
{
	int length = left->GetGenotypeLength();
	std::vector<int> newGenotype = right->GetGenotypeCopy();
	int currPos = 0;
	do {
		currPos = right->GeneAt(currPos);
		newGenotype[currPos] = left->GeneAt(currPos);
	} while (currPos != 0);

	return new Creature(newGenotype);
}
