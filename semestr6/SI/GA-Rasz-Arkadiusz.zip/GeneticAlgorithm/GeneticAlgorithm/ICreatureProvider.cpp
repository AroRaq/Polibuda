#include "ICreatureProvider.h"

ICreatureProvider::ICreatureProvider(double crossoverChance)
{
	_crossoverChance = crossoverChance;
}
