#pragma once

#include "Creature.h"

class ICrossover {
public:
	virtual Creature* Cross(Creature* left, Creature* right) = 0;

private:

};