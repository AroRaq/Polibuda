#pragma once

#include <vector>
#include <limits>
#include "Creature.h"
#include "Problem.h"
#include "IMutator.h"
#include "RunData.h"
#include "CrossoverStep.h"
#include "RandomCreatureProvider.h"

class GARunner {
public:
	GARunner(
		Problem* problem,
		int population, 
		int generations,
		IMutator* mutator);
	~GARunner();
	void Run();
	void SaveResult(std::string path);
	void AddCrossoverStep(CrossoverStep* step);


private:
	void GenerateInitialGeneration();
	void EvaluateGeneration(int generation);
	void Cross();
	void Mutate();

	int _population;
	int _generations;
	std::vector<Creature*>* _currentGeneration;
	Problem* _problem;
	IMutator* _mutator;
	RunData* _runData;
	std::vector<CrossoverStep*> _crossoverSteps;
	RandomCreatureProvider* _randomCreatureProvider;
	Creature* _bestCreature;

};

