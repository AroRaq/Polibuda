#include "CycleCrossoverResultProvider.h"

CycleCrossoverResultProvider::CycleCrossoverResultProvider(double crossoverChance)
	: ICreatureProvider(crossoverChance)
{ 
}

Creature* CycleCrossoverResultProvider::GenerateCreature(Creature* left, Creature* right)
{
	if (Utils::Chance(_crossoverChance) == false) {
		if (left->ShouldBeDeleted() == false) {
			return new Creature(*right);
		}
		else {
			left->KeepInstance();
			return left;
		}
	}

	int length = left->GetGenotypeLength();
	std::vector<int> newGenotype = right->GetGenotypeCopy();
	int startIdx = Utils::RandInt(0, length-1);
	int idx = startIdx;
	do {
		newGenotype[idx] = left->GeneAt(idx);
		int searchFor = left->GeneAt(idx);
		do{
			idx = (idx+1)%length;
		} while (right->GeneAt(idx) != searchFor);
	} while (idx != startIdx);

	return new Creature(newGenotype);
}
