#pragma once

#include "ICrossover.h"

class CycleCrossover : ICrossover {
public:
	Creature* Cross(Creature* left, Creature* right) override;
};