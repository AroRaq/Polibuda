#include "TSPFileReader.h"

Problem* TSPFileReader::ReadProblemFromFile(std::string path)
{
	std::fstream file(path);
	if (!file.is_open())
		throw std::runtime_error("Could not open file " + path);

	std::string line;
	int problemSize = -1;
	std::string name;
	while (std::getline(file, line) && line != "NODE_COORD_SECTION") {
		ReadParameter<int>(line, "DIMENSION", problemSize);
		ReadParameter<std::string>(line, "NAME", name);
	}
	if (problemSize == -1)
		throw std::runtime_error("Could not read problem size");

	long point;
	long double x, y;
	std::vector<Point*> points(problemSize);
	while (file >> point >> x >> y) {
		points[point-1] = new Point(x, y);
	}
	file.close();
	auto pointProvider = new PointProvider(points);
	return new Problem(name, problemSize, 0, pointProvider);
}

