#pragma once

#include <vector>
#include "Creature.h"

class IParentSelector {
public:
	virtual Creature* GetParent(std::vector<Creature*>* population) = 0;
	virtual void Reset() = 0;

protected:

};