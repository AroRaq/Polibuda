#include "TourSelector.h"

TourSelector::TourSelector(int tourSize)
{
	_tourSize = tourSize;
}

Creature* TourSelector::GetParent(std::vector<Creature*>* population)
{
	Creature* result = nullptr;
	for (int i = 0; i < _tourSize; i++) {
		auto randomCreature = Utils::RandElement(population);
		if (result == nullptr || randomCreature->Fitness > result->Fitness) {
			result = randomCreature;
		};
	};
	return result;
}

void TourSelector::Reset() { }
