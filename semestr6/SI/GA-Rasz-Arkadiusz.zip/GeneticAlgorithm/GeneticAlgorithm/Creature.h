#pragma once

#include <vector>
#include <iostream>

class Creature {
public:
	Creature(std::vector<int> genotype);
	Creature(Creature& creature);
	~Creature();
	int GetGenotypeLength();
	int& GeneAt(int position);
	std::vector<int> GetGenotypeCopy();
	long double Fitness = -100000000;
	void KeepInstance();
	void Reset();
	bool ShouldBeDeleted();

private:

	std::vector<int>* _genotype;
	bool _toDelete = true;
	
};