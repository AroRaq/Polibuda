#include <iostream>
#include <string>
#include "GARunner.h"
#include "CycleCrossoverResultProvider.h"
#include "TSPFileReader.h"
#include "SwapMutator.h"
#include "InversionMutator.h"
#include "NullMutator.h"
#include "TourSelector.h"
#include "RouletteSelector.h"
#include "GreedyProvider.h"
#include "NullSelector.h"

void RunRandom(Problem* problem) {
	std::cout << "Running random solver\n";
	auto mutator = new NullMutator();
	auto runner = new GARunner(problem, 1000, 10000, mutator);

	runner->Run();
	runner->SaveResult("C:\\results\\random");
};

void RunTurney(Problem* problem) {
	std::cout << "Running solver with turney\n";
	for (int i = 0; i < 10; i++) {
		std::cout << "Run " << i << std::endl;
		auto mutator = new InversionMutator(0.5);
		auto runner = new GARunner(problem, 500, 10000, mutator);
		auto provider = new CycleCrossoverResultProvider(0.4);
		auto parentSelector = new TourSelector(6);
		runner->AddCrossoverStep(new CrossoverStep(provider, parentSelector, 1));

		runner->Run();
		runner->SaveResult("C:\\results\\tour6_pop500_newCX" + std::to_string(i));
		delete runner;
	}
	//auto mutator = new SwapMutator(0.1);

};

void RunRoulette(Problem* problem) {
	std::cout << "Running solver with roulette selection\n";
	for (int i = 0; i < 10; i++) {
		auto mutator = new InversionMutator(0.5);
		//auto mutator = new InversionMutator(0);
		auto runner = new GARunner(problem, 500, 10000, mutator);
		auto provider = new CycleCrossoverResultProvider(0.4);
		auto parentSelector = new RouletteSelector();
		runner->AddCrossoverStep(new CrossoverStep(provider, parentSelector, 1));

		runner->Run();
		runner->SaveResult("C:\\results\\roulette_pop500_0-5_0-4_" + std::to_string(i));
		delete runner;
	}
};

void RunGreedy(Problem* problem) {
	std::cout << "Running solver with greedy selection\n";
	auto mutator = new NullMutator();
	auto runner = new GARunner(problem, 1, problem->GetSize(), mutator);
	auto provider = new GreedyProvider(problem->GetPointProvider());
	auto parentSelector = new NullSelector();
	runner->AddCrossoverStep(new CrossoverStep(provider, parentSelector, 1));

	runner->Run();
	runner->SaveResult("C:\\results\\greedy");
};

int main()
{
	std::cout.sync_with_stdio(false);
    std::cout << "Hello World!\n";
	auto fileReader = new TSPFileReader();
	auto problem = fileReader->ReadProblemFromFile("TestData/fl417.tsp");

	RunTurney(problem);
}

