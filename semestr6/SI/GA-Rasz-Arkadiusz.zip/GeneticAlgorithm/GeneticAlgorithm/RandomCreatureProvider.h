#pragma once

#include "ICreatureProvider.h"
#include "Utils.h"

class RandomCreatureProvider : public ICreatureProvider {
public:
	RandomCreatureProvider(int genotypeLength);
	virtual Creature* GenerateCreature(Creature* left, Creature* right) override;

private:
	int _genotypeLength;
	std::vector<int> _previousGenotype;
};

