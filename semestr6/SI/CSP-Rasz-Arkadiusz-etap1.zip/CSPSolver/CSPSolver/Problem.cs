﻿
using System.Collections.Generic;

namespace CSPSolver
{
  internal abstract class Problem<TVariable, TValue>
  {
    public abstract bool IsCorrect(TVariable variable, TValue solution);
    public abstract Problem<TVariable, TValue> WithValue(TVariable variable, TValue solution);
    public abstract TVariable GetFirstEmptyVariable();
    public abstract IList<TValue> Domain { get; }
  }
}
