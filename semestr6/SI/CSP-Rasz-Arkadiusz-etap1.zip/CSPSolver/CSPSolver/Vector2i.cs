﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSPSolver
{
  class Vector2i
  {
    public Vector2i(int y, int x)
    {
      X = x;
      Y = y;
    }

    public int X { get; set; }
    public int Y { get; set; }

    public override bool Equals(object? obj)
    {
      if (obj is Vector2i vec)
        return vec.X == X && vec.Y == Y;
      return false;
    }

    public override int GetHashCode()
    {
      return X.GetHashCode() ^ Y.GetHashCode();
    }
  }
}
