﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace CSPSolver.Extensions
{
  internal static class ConcurrentBagExtensions
  {
    public static void AddRange<T>(this ConcurrentBag<T> bag, IEnumerable<T> collection)
    {
      foreach (var item in collection)
      {
        bag.Add(item);
      }
    }
  }
}
