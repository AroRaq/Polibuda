﻿namespace CSPSolver.Mapping
{
  class SudokuDTO
  {
    public int Id { get; set; }
    public int Difficulty { get; set; }
    public string Puzzle { get; set; }
    public string Solution { get; set; }
  }
}
