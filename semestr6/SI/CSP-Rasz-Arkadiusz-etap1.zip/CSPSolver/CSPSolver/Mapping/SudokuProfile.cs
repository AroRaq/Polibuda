﻿using AutoMapper;

namespace CSPSolver.Mapping
{
  internal class SudokuProfile : Profile
  {
    public SudokuProfile()
    {
      CreateMap<SudokuDTO, Sudoku.Sudoku>()
        .ConvertUsing(SudokuDtoToProblemConverter);
    }

    private Sudoku.Sudoku SudokuDtoToProblemConverter(SudokuDTO dto, Sudoku.Sudoku _)
    {
      var board = new int?[9, 9];
      var (x, y) = (0, 0);
      foreach (var c in dto.Puzzle)
      {
        if (c == '.')
          board[y, x] = null;
        else
          board[y, x] = (int)char.GetNumericValue(c);
        x++;
        if (x >= 9)
        {
          x = 0;
          y++;
        }
      }
      return new Sudoku.Sudoku(dto.Id, board);
    }
  }
}
