﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace CSPSolver.WordFill
{
  internal class WordFill : Problem<WordFillVariable, string>
  {
    public override IList<string> Domain { get; }
    private readonly char?[,] _board;
    private readonly List<WordFillVariable> _variables = new List<WordFillVariable>();

    public WordFill(char?[,] board, IEnumerable<string> words)
    {
      Domain = words.ToList();
      _board = board;
      PreProcess();
    }

    private WordFill(WordFill other)
    {
      Domain = other.Domain.ToList();
      _board = other._board.Clone() as char?[,];
      _variables = other._variables.ToList();
    }

    private void PreProcess()
    {
      for (var y = 0; y < _board.GetLength(0); y++)
      {
        for (var x = 0; x < _board.GetLength(1); x++)
        {
          if (IsWordBeginning(y, x, WordDirection.Right))
          {
            var wordLength = 0;
            var startX = x;
            while (x != _board.GetLength(1) && _board[y, x] == ' ')
            {
              wordLength++;
              x++;
            }
            _variables.Add(new WordFillVariable(y, startX, wordLength, WordDirection.Right));
          }
        }
      }

      for (var x = 0; x < _board.GetLength(1); x++)
      {
        for (var y = 0; y < _board.GetLength(0); y++)
        {
          if (IsWordBeginning(y, x, WordDirection.Down))
          {
            var wordLength = 0;
            var startY = y;
            while (y != _board.GetLength(0) && _board[y, x] == ' ')
            {
              wordLength++;
              y++;
            }
            _variables.Add(new WordFillVariable(startY, x, wordLength, WordDirection.Down));
          }
        }
      }
    }

    private bool IsWordBeginning(int y, int x, WordDirection dir)
    {
      return dir switch
      {
        WordDirection.Right => (_board[y, x] == ' ' && 
                                (x == 0 || _board[y, x - 1] == null) &&
                                (x + 1 != _board.GetLength(1) && _board[y, x + 1] == ' ')),
        WordDirection.Down => (_board[y, x] == ' ' && 
                               (y == 0 || _board[y - 1, x] == null) &&
                               (y + 1 != _board.GetLength(0) && _board[y + 1, x] == ' ')),
        _ => throw new ArgumentOutOfRangeException(nameof(dir), dir, null)
      };
    } 

    public override bool IsCorrect(WordFillVariable variable, string solution)
    {
      if (variable.WordLength != solution.Length)
        return false;

      for (var i = 0; i < solution.Length; i++)
      {
        switch (variable.WordDirection)
        {
          case WordDirection.Right when _board[variable.Y, variable.X + i] != solution[i] && _board[variable.Y, variable.X + i] != ' ':
          case WordDirection.Down when _board[variable.Y + i, variable.X] != solution[i] && _board[variable.Y + i, variable.X] != ' ':
            return false;
        }
      }

      return true;
    }

    public override Problem<WordFillVariable, string> WithValue(WordFillVariable variable, string solution)
    {
      Debug.Assert(IsCorrect(variable, solution));
      var next = new WordFill(this);

      for (var i = 0; i < solution.Length; i++)
      {
        switch (variable.WordDirection)
        {
          case WordDirection.Right:
            next._board[variable.Y, variable.X + i] = solution[i];
            break;
          case WordDirection.Down:
            next._board[variable.Y + i, variable.X] = solution[i];
            break;
          default:
            throw new ArgumentOutOfRangeException();
        }
      }

      next._variables.Remove(variable);
      next.Domain.Remove(solution);
      return next;
    }

    public override WordFillVariable GetFirstEmptyVariable()
    {
      return _variables.FirstOrDefault();
    }

    public override string ToString()
    {
      var stringBuilder = new StringBuilder();
      for (var y = 0; y < _board.GetLength(0); y++)
      {
        for (var x = 0; x < _board.GetLength(1); x++)
        {
          stringBuilder.Append(_board[y, x]?.ToString() ?? "#");
        }

        stringBuilder.AppendLine();
      }

      return stringBuilder.ToString();
    }
  }
}
