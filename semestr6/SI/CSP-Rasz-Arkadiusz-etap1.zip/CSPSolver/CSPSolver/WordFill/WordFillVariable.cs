﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSPSolver.WordFill
{
  internal class WordFillVariable
  {
    public WordFillVariable(int y, int x, int wordLength, WordDirection wordDirection)
    {
      X = x;
      Y = y;
      WordLength = wordLength;
      WordDirection = wordDirection;
    }

    public int X { get; }
    public int Y { get; }
    public int WordLength { get; }
    public WordDirection WordDirection { get; }

    public override bool Equals(object? obj)
    {
      if (obj is WordFillVariable v)
        return v.X == X && v.Y == Y && v.WordDirection == WordDirection;
      return false;
    }

    public override int GetHashCode() => 
      X.GetHashCode() ^ Y.GetHashCode() ^ WordDirection.GetHashCode();
  }

  enum WordDirection
  {
    Right,
    Down
  }
}
