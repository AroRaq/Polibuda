﻿using System;
using System.Collections.Generic;
using System.IO;

namespace CSPSolver.WordFill
{
  internal class WordFillFileReader
  {
    public IList<WordFill> ReadFromFiles()
    {
      var puzzles = new List<WordFill>();
      for (var i = 0; i <= 4; i++)
      {
        var lines = File.ReadAllLines($"Problems/Jolka/puzzle{i}");
        var board = new char?[lines.Length, lines[0].Length];
        for (var y = 0; y < lines.Length; y++)
        {
          for (var x = 0; x < lines[y].Length; x++)
          {
            board[y, x] = lines[y][x] switch
            {
              '_' => ' ',
              '#' => null,
              _ => throw new ArgumentException($"No such value for word fill puzzle: {lines[y][x]}")
            };
          }
        }

        var words = File.ReadAllLines($"Problems/Jolka/words{i}");
        puzzles.Add(new WordFill(board, words));
      }

      return puzzles;
    }

  }
}
