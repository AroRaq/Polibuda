﻿using System;
using System.Collections.Generic;
using System.Linq;
using AutoMapper;
using CSPSolver.Mapping;
using CSPSolver.Sudoku;
using CSPSolver.WordFill;

namespace CSPSolver
{
  internal class Program
  {
    static void Main(string[] args)
    {
      var configuration = new MapperConfiguration(cfg => 
        cfg.AddProfile<SudokuProfile>());

      var program = new Program
      {
        _mapper = new Mapper(configuration)
      };
      program.SolveSudokus();

    }

    private IMapper _mapper;

    private void SolveSudokus()
    {
      var reader = new SudokuFileReader();
      var dtos = reader.ReadFromFile("Problems/Sudoku.csv");
      var sudokus = _mapper.Map<List<SudokuDTO>, List<Sudoku.Sudoku>>(dtos);

      foreach (var sudoku in sudokus)
      {
        var solver = new RecursiveProblemSolver();
        Console.WriteLine($"ID: {sudoku.Id}");
        var (isSolved, solutions) = solver.GetAllSolutions(sudoku);
        Console.WriteLine(isSolved
          ? solutions.Aggregate("", (s, problem) => s += $"\n{problem}")
          : "No solution found!");
        Console.WriteLine(solver.Stats);
        Console.WriteLine();
      }
    }

    private void SolveWordFills()
    {
      var reader = new WordFillFileReader();
      var problems = reader.ReadFromFiles();
      foreach (var problem in problems)
      {
        var solver = new RecursiveProblemSolver();
        Console.WriteLine();
        var (isSolved, solutions) = solver.GetAllSolutions(problem);
        Console.WriteLine(isSolved
          ? solutions.Aggregate("", (s, p) => s += $"\n{p}")
          : "No solution found!");
        Console.WriteLine(solver.Stats);
        Console.WriteLine();
      }
    }
  }
}
