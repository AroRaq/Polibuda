﻿
using System.Collections.Generic;
using System.Linq;

namespace CSPSolver
{
  internal class RecursiveProblemSolver
  {
    private int nodesUntilFirst = 0;
    private int reversesUntilFirst = 0;
    private int nodesCount = 0;
    private int reversesCount = 0;
    private int solutionCount = 0;

    private bool m_isSolved = false;


    public (bool isSolved, Problem<TVariable, T> solution) Solve<TVariable, T>(Problem<TVariable, T> problem)
    {

      var variable = problem.GetFirstEmptyVariable();
      if (variable == null)
        return (true, problem);

      foreach (var value in problem.Domain)
      {
        if (problem.IsCorrect(variable, value))
        {
          var (isSolved, solvedSudoku) = Solve(problem.WithValue(variable, value));
          if (isSolved == true)
            return (true, solvedSudoku);
        }
      }

      return (false, null);
    }

    public (bool isSolved, List<Problem<TVariable, T>> solutions) GetAllSolutions<TVariable, T>(Problem<TVariable, T> problem)
    {
      nodesCount++;
      if (m_isSolved == false)
        nodesUntilFirst++;
      var variable = problem.GetFirstEmptyVariable();
      if (variable == null)
      {
        m_isSolved = true;
        solutionCount++;
        return (true, new List<Problem<TVariable, T>> {problem});
      }

      var solutions = new List<Problem<TVariable, T>>();

      foreach (var value in problem.Domain)
      {
        if (problem.IsCorrect(variable, value))
        {
          var (isSolved, foundSolutions) = GetAllSolutions(problem.WithValue(variable, value));
          if (isSolved == true)
            solutions.AddRange(foundSolutions);
        }
      }

      reversesCount++;
      if (m_isSolved == false)
        reversesUntilFirst++;

      return solutions.Any() 
        ? (true, solutions) 
        : (false, null);
    }


    public string Stats =>
      $"Solutions found                    : {solutionCount}\n" +
      $"Nodes searched until first solution: {nodesUntilFirst}\n" +
      $"Nodes searched until all solutions : {nodesCount}\n" +
      $"Reverses until first solution      : {reversesUntilFirst}\n" +
      $"Reverses until all solutions       : {reversesCount}\n";
  }
}
