﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;

[assembly: InternalsVisibleTo("CSPSolver.Test")]
namespace CSPSolver.Sudoku
{
  internal class Sudoku : Problem<Vector2i, int>
  {
    internal Sudoku(int id,int?[,] board)
    {
      Id = id;
      Board = board;
    }

    public int Id { get; }

    public int?[,] Board { get; }

    private bool VerifySquare(Vector2i field, int value)
    {
      var top = (field.Y / 3) * 3;
      var left = (field.X / 3) * 3;

      for (var y = top; y < top + 3; y++)
        for (var x = left; x < left + 3; x++)
          if (value == Board[y, x])
            return false;

      return true;
    }

    private bool VerifyLines(Vector2i field, int value)
    {
      for (var y = 0; y < 9; y++)
        if (Board[y, field.X] == value)
          return false;

      for (var x = 0; x < 9; x++)
        if (Board[field.Y, x] == value)
          return false;

      return true;

    }

    public override string ToString()
    {
      var stringBuilder = new StringBuilder();
      for (var y = 0; y < 9; y++)
      {
        for (var x = 0; x < 9; x++)
        {
          stringBuilder.Append(Board[y, x]?.ToString() ?? " ");
          if (x == 2 || x == 5)
            stringBuilder.Append('|');
        }
        stringBuilder.AppendLine();
        if (y == 2 || y == 5)
          stringBuilder.AppendLine("---+---+---");
      }

      return stringBuilder.ToString();
    }

    public override bool IsCorrect(Vector2i variable, int solution)
    {
      if (Board[variable.Y, variable.X] != null)
        return false;

      return VerifyLines(variable, solution) && VerifySquare(variable, solution);
    }

    public override Problem<Vector2i, int> WithValue(Vector2i variable, int solution)
    {
      var next = new Sudoku(Id, Board.Clone() as int?[,]);
      if (next.Board[variable.Y, variable.X] != null)
        throw new InvalidOperationException(
          $"Field already filled: [Y:{variable.Y}, X:{variable.X}, Val:{solution}]");

      next.Board[variable.Y, variable.X] = solution;
      return next;
    }


    public override Vector2i GetFirstEmptyVariable()
    {
      for (var y = 0; y < 9; y++)
        for (var x = 0; x < 9; x++)
          if (Board[y, x] == null)
            return new Vector2i(y, x);

      return null;
    }

    private readonly List<int> _domain = Enumerable.Range(1, 9).ToList();
    public override IList<int> Domain => _domain;
  }
}
