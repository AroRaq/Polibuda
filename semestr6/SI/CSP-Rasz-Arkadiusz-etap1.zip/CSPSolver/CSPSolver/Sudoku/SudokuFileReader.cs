﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CSPSolver.Mapping;
using CsvHelper;

namespace CSPSolver.Sudoku
{
  internal class SudokuFileReader
  {
    public List<SudokuDTO> ReadFromFile(string path)
    {
      using var reader = new StreamReader(path);
      using var csvReader = new CsvReader(reader, CultureInfo.InvariantCulture); 
      var dtos = csvReader.GetRecords<SudokuDTO>();
      return dtos.ToList();
    }
  }
}
