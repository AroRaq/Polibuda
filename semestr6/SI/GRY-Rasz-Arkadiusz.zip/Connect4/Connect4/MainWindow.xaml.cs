﻿using System.Text.RegularExpressions;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Connect4
{
  /// <summary>
  /// Interaction logic for MainWindow.xaml
  /// </summary>
  public partial class MainWindow : Window
  {
    private WindowViewModel _windowViewModel;
    private GameCanvas _gameCanvas;
    public MainWindow()
    {
      InitializeComponent();

    }

    private void Canvas_Click(object sender, MouseButtonEventArgs e)
    {
      _gameCanvas.OnClicked(sender, e);
    }

    private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
    {
      var regex = new Regex("[^0-9]+");
      e.Handled = regex.IsMatch(e.Text);
    }

    private void TextBoxBase_OnTextChanged(object sender, TextChangedEventArgs e)
    {
      LogOutput.ScrollToEnd();
    }

    private void MainWindow_OnLoaded(object sender, RoutedEventArgs e)
    {
      var canvas = this.FindName("GameCanvas") as Canvas;
      _gameCanvas = new GameCanvas(canvas);
      _windowViewModel = new WindowViewModel(_gameCanvas);
      DataContext = _windowViewModel;

    }
  }
}
