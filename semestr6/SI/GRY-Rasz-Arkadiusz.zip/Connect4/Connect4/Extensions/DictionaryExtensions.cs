﻿using System;
using System.Collections.Generic;

namespace Connect4.Extensions
{
  public static class DictionaryExtensions
  {
    public static TValue GetOrCreate<TKey, TValue>(this Dictionary<TKey, TValue> dictionary, TKey key, Func<TValue> factory)
    {
      if (dictionary.TryGetValue(key, out var value))
        return value;
      var result = factory();
      dictionary[key] = result;
      return result;
    }
  }
}
