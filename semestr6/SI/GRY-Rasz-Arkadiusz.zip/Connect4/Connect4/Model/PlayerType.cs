﻿using System;
using Connect4.Controller;

namespace Connect4
{
  public class PlayerType
  {
    public string Name { get; set; }
    public Func<ControllerConfiguration, IController> ControllerFactory { get; set; }
  }
}