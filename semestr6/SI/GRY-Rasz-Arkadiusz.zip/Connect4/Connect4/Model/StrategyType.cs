﻿namespace Connect4
{
  public class StrategyType
  {
    public string Name { get; set; }
    public int[] Strategy { get; set; }
  }
}