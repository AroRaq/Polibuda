﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Connect4.Test")]
namespace Connect4.Model
{
  public class GameState
  {
    private readonly int[] _columnFillLevel;

    public GameConfiguration Configuration { get; } = new GameConfiguration();
    public Player PlayerToMove { get; private set; } = Player.Player1;
    public FieldState[,] Field { get; }
    public bool IsCompleted { get; private set; }
    public Player? WinningPlayer { get; private set; }


    // internal GameState(FieldState[,] field, Player player)
    // {
    //   Field = field;
    //   _columnFillLevel = new int[Configuration.ColumnCount];
    //   for (var i = 0; i < Configuration.ColumnCount; i++)
    //   {
    //     _columnFillLevel[i] = Configuration.RowCount;
    //     for (var j = 0; j < Configuration.RowCount; j++)
    //     {
    //       if (Field[j, i] == FieldState.Empty)
    //       {
    //         _columnFillLevel[i] = j;
    //         break;
    //       }
    //     }
    //   }
    //   PlayerToMove = player;
    // }

    private GameState()
    {
      Field = new FieldState[Configuration.RowCount, Configuration.ColumnCount];
      _columnFillLevel = new int[Configuration.ColumnCount];
    }

    private GameState(GameState other)
    {
      Field = other.Field.Clone() as FieldState[,];
      _columnFillLevel = other._columnFillLevel.Clone() as int[];
      PlayerToMove = other.PlayerToMove;
      Configuration = other.Configuration;
    }

    public static GameState Empty => new GameState();

    public IEnumerable<int> PossibleColumnsToMove
    {
      get
      {
        var start = Configuration.ColumnCount / 2;
        for (var i = start; i < Configuration.ColumnCount; i++)
          if (_columnFillLevel[i] < Configuration.RowCount)
            yield return i;
        for (var i = 0; i < start; i++)
          if (_columnFillLevel[i] < Configuration.RowCount)
            yield return i;

        // for (var i = 0; i < Configuration.ColumnCount; i++)
        //   if (_columnFillLevel[i] < Configuration.RowCount)
        //     yield return i;
      }
    }


    public GameState AfterMove(int column, Player player)
    {
      Debug.Assert(PlayerToMove == player);
      var newState = new GameState(this);
      newState.FillColumn(column, player);
      return newState;
    }

    public (int filledRow, int filledColumn) FillColumn(int column, Player player)
    {
      var row = _columnFillLevel[column];
      Debug.Assert(row < Configuration.RowCount);
      Debug.Assert(Field[row, column] == FieldState.Empty);
      Field[row, column] = player switch
      {
        Player.Player1 => FieldState.Player1,
        Player.Player2 => FieldState.Player2,
        _ => throw new ArgumentException(nameof(column))
      };
      _columnFillLevel[column]++;
      IsCompleted = CheckForCompletion(row, column);
      if (IsCompleted && PossibleColumnsToMove.Any())
        WinningPlayer = player;
      PlayerToMove = player.Other();
      return (row, column);
    }

    public bool CheckForCompletion(int rowLastMove, int columnLastMove)
    {
      return WinningSequence != null || PossibleColumnsToMove.Any() == false;
      if (PossibleColumnsToMove.Any() == false)
        return true;

      var horizontal = CountPlayerSequence(columnLastMove, rowLastMove, 0, -1)
                         + CountPlayerSequence(columnLastMove, rowLastMove, 0, 1) - 1;
      if (horizontal == Configuration.WinningNumber)
        return true;

      var vertical = CountPlayerSequence(columnLastMove, rowLastMove, -1, 0)
                       + CountPlayerSequence(columnLastMove, rowLastMove, 1, 0) - 1;
      if (vertical == Configuration.WinningNumber)
        return true;

      var diagonal1 = CountPlayerSequence(columnLastMove, rowLastMove, 1, -1)
                       + CountPlayerSequence(columnLastMove, rowLastMove, -1, 1) - 1;
      if (diagonal1 == Configuration.WinningNumber)
        return true;

      var diagonal2 = CountPlayerSequence(columnLastMove, rowLastMove, -1, -1)
                      + CountPlayerSequence(columnLastMove, rowLastMove, 1, 1) - 1;
      if (diagonal2 == Configuration.WinningNumber)
        return true;

      return false;
    }

    private int CountPlayerSequence(int startingColumn, int startingRow, int yIncr, int xIncr)
    {
      var searchField = Field[startingRow, startingColumn];
      var count = 0;
      for (var (y, x) = (startingRow, startingColumn);
        y >= 0 && y < Configuration.RowCount && x >= 0 && x < Configuration.ColumnCount;
        y += yIncr, x += xIncr)
      {
        if (Field[y, x] != searchField)
          return count;
        count++;
      }

      return count;
    }

    internal IEnumerable<FieldSequence> HorizontalSequences
    {
      get
      {
        for (var y = 0; y < Configuration.RowCount; y++)
        for (var x = 0; x < Configuration.ColumnCount - Configuration.WinningNumber + 1; x++)
          yield return new FieldSequence(Field, y, x, Configuration.WinningNumber, FieldSequence.Direction.Right);
      }
    }

    internal IEnumerable<FieldSequence> VerticalSequences
    {
      get
      {
        for (var x = 0; x < Configuration.ColumnCount; x++)
        for (var y = 0; y < Configuration.RowCount - Configuration.WinningNumber + 1; y++)
          yield return new FieldSequence(Field, y, x, Configuration.WinningNumber, FieldSequence.Direction.Up);
      }
    }

    internal IEnumerable<FieldSequence> DiagonalRisingSequences
    {
      get
      {
        for (var x = 0; x < Configuration.ColumnCount - Configuration.WinningNumber + 1; x++)
        for (var y = 0; y < Configuration.RowCount - Configuration.WinningNumber + 1; y++)
          yield return new FieldSequence(Field, y, x, Configuration.WinningNumber, FieldSequence.Direction.UpRight);
      }
    }

    internal IEnumerable<FieldSequence> DiagonalFallingSequences
    {
      get
      {
        for (var x = 0; x < Configuration.ColumnCount - Configuration.WinningNumber + 1; x++)
        for (var y = Configuration.RowCount - 1; y >= Configuration.WinningNumber - 1; y--)
          yield return new FieldSequence(Field, y, x, Configuration.WinningNumber, FieldSequence.Direction.DownRight);
      }
    }

    public FieldSequence WinningSequence
    {
      get
      {
        // Debug.Assert(IsCompleted);
        var sequences = HorizontalSequences
          .Union(VerticalSequences)
          .Union(DiagonalRisingSequences)
          .Union(DiagonalFallingSequences);
        return sequences
          .FirstOrDefault(sequence => 
            sequence.Fields.Count(f => f.value == FieldState.Player1) == Configuration.WinningNumber || 
            sequence.Fields.Count(f => f.value == FieldState.Player2) == Configuration.WinningNumber);
      }
    }

    public override int GetHashCode() => Field.Cast<FieldState>().Aggregate(0, HashCode.Combine);
  }



  public enum FieldState
  {
    Empty = 0,
    Player1 = 1,
    Player2 = 2
  }
}
