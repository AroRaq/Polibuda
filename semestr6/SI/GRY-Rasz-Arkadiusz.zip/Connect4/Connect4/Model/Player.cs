﻿namespace Connect4.Model
{
  public enum Player
  {
    Player1 = 1,
    Player2 = 2
  }

  public static class PlayerExtensions
  {
    public static Player Other(this Player player) => player == Player.Player1 ? Player.Player2 : Player.Player1;
  }
}