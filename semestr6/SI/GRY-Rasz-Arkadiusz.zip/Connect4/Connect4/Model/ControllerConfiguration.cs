﻿using Connect4.Model;
using Connect4.Service;

namespace Connect4
{
  public class ControllerConfiguration
  {
    public int[] Strategy { get; set; }
    public int SearchDepth { get; set; }
    public Player Player { get; set; }
    public GameStateService GameStateService { get; set; }
  }
}