﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using Connect4.Annotations;
using Connect4.Controller;
using Connect4.Model;
using Connect4.Service;
using Microsoft.Extensions.Logging;

namespace Connect4
{
  internal class WindowViewModel : INotifyPropertyChanged
  {
    private readonly GameCanvas _canvas;
    private readonly GameStateService _gameStateService;

    private CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();

    private PlayerType _selectedController1;
    private PlayerType _selectedController2;
    private StrategyType _selectedStrategy1;
    private StrategyType _selectedStrategy2;
    private string _strategyParameters1Text = "1,1,1,1,1,1";
    private string _strategyParameters2Text = "1,1,1,1,1,1";
    private string _searchDepth1Text = "9";
    private string _searchDepth2Text = "9";
    private ICommand _startGameCommand;

    public ICommand StartGameCommand =>
      _startGameCommand ??= new RelayCommand(async obj => await OnStartButtonClicked(), obj => true);


    internal WindowViewModel(GameCanvas canvas)
    {
      _gameStateService = new GameStateService();
      _canvas = canvas;
      PlayerTypes = new List<PlayerType> {
        new PlayerType { Name = "Human",
          ControllerFactory = _ => new PlayerController(_canvas) },
        new PlayerType { Name = "MiniMax",
          ControllerFactory = config => new MinimaxController(config) },
        new PlayerType { Name = "Alpha-Beta",
          ControllerFactory = config => new AlphaBetaController(config) }
      };
      StrategyTypes = new List<StrategyType>
      {
        new StrategyType {Name = "Aggressive", Strategy = new[] {1, 0, 0, 1, 0, 1}},
        new StrategyType {Name = "Mixed", Strategy = new[] {2, -1, -1, 1, -1, 1}},
        new StrategyType {Name = "Defensive", Strategy = new[] {0, -1, -1, 0, -1, 0}},
        new StrategyType {Name = "Custom", Strategy = null}
      };

      _selectedController1 = PlayerTypes.Single(p => p.Name == "Alpha-Beta");
      _selectedStrategy1 = StrategyTypes.Single(s => s.Name == "Aggressive");


      _selectedController2 = PlayerTypes.Single(p => p.Name == "Alpha-Beta");
      _selectedStrategy2 = StrategyTypes.Single(s => s.Name == "Aggressive");
    }

    public event PropertyChangedEventHandler PropertyChanged;



    [NotifyPropertyChangedInvocator]
    protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
    {
      PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
    }




    public bool IsSelectedPlayer1AI => SelectedPlayer1?.Name != "Human";
    public bool IsSelectedPlayer2AI => SelectedPlayer2?.Name != "Human";
    public bool IsCustomStrategy1TextBoxEnabled => SelectedStrategy1?.Name == "Custom";
    public bool IsCustomStrategy2TextBoxEnabled => SelectedStrategy2?.Name == "Custom";

    public List<PlayerType> PlayerTypes { get; }

    public List<StrategyType> StrategyTypes { get; }

    public PlayerType SelectedPlayer1
    {
      get => _selectedController1;
      set
      {
        _selectedController1 = value;
        OnPropertyChanged();
        OnPropertyChanged(nameof(IsSelectedPlayer1AI));
      }
    }

    public PlayerType SelectedPlayer2
    {
      get => _selectedController2;
      set
      {
        _selectedController2 = value;
        OnPropertyChanged();
        OnPropertyChanged(nameof(IsSelectedPlayer2AI));
      }
    }

    public StrategyType SelectedStrategy1
    {
      get => _selectedStrategy1;
      set
      {
        _selectedStrategy1 = value;
        OnPropertyChanged();
        OnPropertyChanged(nameof(IsCustomStrategy1TextBoxEnabled));
      }
    }

    public StrategyType SelectedStrategy2
    {
      get => _selectedStrategy2;
      set
      {
        _selectedStrategy2 = value;
        OnPropertyChanged();
        OnPropertyChanged(nameof(IsCustomStrategy2TextBoxEnabled));
      }
    }

    public string StrategyParameters1Text
    {
      get => _strategyParameters1Text;
      set
      {
        _strategyParameters1Text = value;
        OnPropertyChanged();
      }
    }

    public string StrategyParameters2Text
    {
      get => _strategyParameters2Text;
      set
      {
        _strategyParameters2Text = value;
        OnPropertyChanged();
      }
    }


    public string SearchDepth1Text
    {
      get => _searchDepth1Text;
      set
      {
        _searchDepth1Text = value;
        OnPropertyChanged();
      }
    }

    public string SearchDepth2Text
    {
      get => _searchDepth2Text;
      set
      {
        _searchDepth2Text = value;
        OnPropertyChanged();
      }
    }

    private string _gameLog = string.Empty;
    public string GameLog
    {
      get => _gameLog;
      set
      {
        _gameLog = value;
        OnPropertyChanged();
      }
    }

    public void Log(string message) => GameLog = $"{GameLog}\n{message}";

    private async Task OnStartButtonClicked()
    {
      var controller1Config = new ControllerConfiguration
      {
        GameStateService = _gameStateService,
        Player = Player.Player1,
        SearchDepth = int.Parse(SearchDepth1Text),
        Strategy = SelectedStrategy1.Strategy ?? StrategyParameters1Text.Split(',').Select(int.Parse).ToArray()
      };
      var controller2Config = new ControllerConfiguration
      {
        GameStateService = _gameStateService,
        Player = Player.Player2,
        SearchDepth = int.Parse(SearchDepth2Text),
        Strategy = SelectedStrategy2.Strategy ?? StrategyParameters2Text.Split(',').Select(int.Parse).ToArray()
      };
      var player1 = _selectedController1.ControllerFactory(controller1Config);
      var player2 = _selectedController2.ControllerFactory(controller2Config);
      _canvas.Clear();
      var engine = new Engine();
      _canvas.Setup(engine.CurrentGameState.Configuration);

      void MoveCallback(int row, int column, Player player) =>
        Application.Current.Dispatcher.Invoke(() => _canvas.PaintMove(row, column, player));
      
      _cancellationTokenSource.Cancel();
      _cancellationTokenSource = new CancellationTokenSource();
      Player? winningPlayer = null;
      try
      {
        Log("Starting new game!");
        winningPlayer = await engine.Run(player1, player2, 
          MoveCallback, _cancellationTokenSource.Token, Log);
      }
      catch (OperationCanceledException)
      {
        return;
      }

      var winningSequence = engine.CurrentGameState.WinningSequence;
      if (winningSequence != null)
      {
        var point1 = winningSequence.Fields.First().coord;
        var point2 = winningSequence.Fields.Last().coord;
        Application.Current.Dispatcher.Invoke(() => _canvas.PaintWin(point1, point2));
      }

      Log(winningPlayer != null 
        ? $"{winningPlayer} won!" 
        : "It's a tie!");
    }
  }
}
