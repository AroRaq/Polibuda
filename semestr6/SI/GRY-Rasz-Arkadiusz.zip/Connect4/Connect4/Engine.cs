﻿using System;
using System.Diagnostics;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Connect4.Controller;
using Connect4.Model;

namespace Connect4
{
  internal class Engine
  {
    public async Task<Player?> Run(IController player1, IController player2,
      Action<int, int, Player> moveCallback, CancellationToken token, Action<string> logFunc)
    {
      Directory.CreateDirectory("res");
      CurrentGameState = GameState.Empty;
      _builder = new StringBuilder();
      Debug.WriteLine("Starting the game!");
      var firstMove = false;
      var random = new Random(DateTime.Now.Millisecond);
      Player? winningPlayer = null;
      while (true)
      {
        int move, score, nodes;
        var timer = Stopwatch.StartNew();
        (move, score, nodes) = firstMove && !(player1 is PlayerController)
          ? (random.Next(CurrentGameState.Configuration.ColumnCount), 0, 0) 
          : await player1.MakeMove(CurrentGameState);
        timer.Stop();
        logFunc($"P1 time: {timer.ElapsedMilliseconds}, score: {score}, nodes: {nodes}");
        WriteToFile(1, nodes);
        token.ThrowIfCancellationRequested();

        var (row, column) = CurrentGameState.FillColumn(move, Player.Player1);
        moveCallback(row, column, Player.Player1);


        if (CurrentGameState.IsCompleted)
        {
          winningPlayer = CurrentGameState.WinningPlayer;
          break;
        }

        timer.Restart();
        (move, score, nodes) = firstMove && !(player2 is PlayerController)
          ? (random.Next(CurrentGameState.Configuration.ColumnCount), 0, 0)
          : await player2.MakeMove(CurrentGameState);
        timer.Stop();
        logFunc($"P2 time: {timer.ElapsedMilliseconds}, score: {score}, nodes: {nodes}");
        WriteToFile(2, nodes);
        token.ThrowIfCancellationRequested();

        (row, column) = CurrentGameState.FillColumn(move, Player.Player2);
        moveCallback(row, column, Player.Player2);

        if (CurrentGameState.IsCompleted)
        {
          winningPlayer = CurrentGameState.WinningPlayer;
          break;
        }

        firstMove = false;
      }
      File.WriteAllText($"res/{DateTime.Now:HH-mm-ss}.csv", _builder.ToString());
      return winningPlayer;
    }

    public void WriteToFile(int player, long num)
    {
      _builder.Append($"{num};");
      if (player == 2)
        _builder.AppendLine();
    }

    private StringBuilder _builder;

    public GameState CurrentGameState { get; private set; } = GameState.Empty;
  }
}
