﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Connect4.Model;

namespace Connect4.Controller
{
  internal class PlayerController : IController
  {
    private readonly GameCanvas _canvas;

    public PlayerController(GameCanvas canvas)
    {
      _canvas = canvas;
    }

    public async Task<(int move, int score, int nodesSearched)> MakeMove(GameState state)
    {
      var possibleMoves = state.PossibleColumnsToMove.ToList();
      var move = -1;
      do
      {
        move = await GetMove(state);

      } while (possibleMoves.Contains(move) == false);

      return (move, 0, 0);
    }

    private async Task<int> GetMove(GameState state)
    {
      var tsc = new TaskCompletionSource<double>();
      _canvas.Subscribe(tsc);
      var mousePositionX = await tsc.Task;
      return (int)(mousePositionX / _canvas.Width * state.Configuration.ColumnCount);
    }
  }
}