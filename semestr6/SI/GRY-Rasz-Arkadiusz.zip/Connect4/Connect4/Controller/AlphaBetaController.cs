﻿using System;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Connect4.Model;
using Connect4.Service;

namespace Connect4.Controller
{
  internal class AlphaBetaController : IController
  {
    private readonly GameStateService _gameStateService;

    private readonly Player _player;
    private readonly int[] _genotype;
    private readonly int _searchDepth;
    public AlphaBetaController(ControllerConfiguration configuration)
    {
      _player = configuration.Player;
      _gameStateService = configuration.GameStateService;
      _genotype = configuration.Strategy.Clone() as int[];
      _searchDepth = configuration.SearchDepth;
      if (_player == Player.Player2)
        for (var i = 0; i < 3; i++)
        {
          var temp = _genotype[2 * i];
          _genotype[2 * i] = _genotype[2 * i + 1];
          _genotype[2 * i + 1] = temp;
        }
    }


    public async Task<(int move, int score, int nodesSearched)> MakeMove(GameState state)
    {
      var task = Task.Factory.StartNew(() => RunMinimaxWithAlphaBeta(state, true, 1,
        int.MinValue, int.MaxValue));
      var (column, score, nodesSearched) = await task;
      Debug.WriteLine($"{_player}: Placing on column {column} based on score of {score}");
      Debug.Assert(column != -1);
      return (column, score, nodesSearched);
    }

    private (int column, int score, int nodesSearched) RunMinimaxWithAlphaBeta
      (GameState state, bool isMax, int currentDepth, int alpha, int beta)
    {
      if (state.PossibleColumnsToMove.Any() == false)
        return (-1, 0, 1);

      if (state.IsCompleted)
        return (-1, state.WinningPlayer == _player
          ? 10000 - currentDepth
          : -10000 + currentDepth, 1);

      if (currentDepth == _searchDepth)
      {
        var data = _gameStateService.EvaluateGameState(state);
        var res = 0;
        for (var i = 0; i < _genotype.Length; i++)
        {
          res += _genotype[i] * data[i];
        }
        return (-1, res, 1);
      }

      var bestScore = isMax ? int.MinValue : int.MaxValue;
      var bestColumn = state.PossibleColumnsToMove.First();
      var nodesSearched = 1;
      if (isMax)
      {
        foreach (var col in state.PossibleColumnsToMove)
        {
          var (_, score, nodes) = RunMinimaxWithAlphaBeta(state.AfterMove(col, _player), false, 
            currentDepth + 1, alpha, beta);
          nodesSearched += nodes;
          if (score > bestScore)
          {
            bestColumn = col;
            bestScore = score;
          }

          alpha = Math.Max(alpha, score);
          if (alpha > beta) break;
        }
      }
      else
      {
        foreach (var col in state.PossibleColumnsToMove)
        {
          var (_, score, nodes) = RunMinimaxWithAlphaBeta(state.AfterMove(col, _player.Other()), true,
            currentDepth + 1, alpha, beta);
          nodesSearched += nodes;
          if (score < bestScore)
          {
            bestColumn = col;
            bestScore = score;
          }

          beta = Math.Min(beta, score);
          if (alpha > beta) break;
        }
      }

      return (bestColumn, bestScore, nodesSearched);
    
  }
  }
}