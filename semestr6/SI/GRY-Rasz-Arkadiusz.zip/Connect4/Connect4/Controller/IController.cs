﻿
using System.Threading.Tasks;
using Connect4.Model;

namespace Connect4.Controller
{
  public interface IController
  {
    public Task<(int move, int score, int nodesSearched)> MakeMove(GameState state);
  }
}
