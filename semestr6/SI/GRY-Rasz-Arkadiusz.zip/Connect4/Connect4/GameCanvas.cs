﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Connect4.Model;

namespace Connect4
{
  internal class GameCanvas
  {
    private readonly Canvas _canvas;
    private readonly List<TaskCompletionSource<double>> _columnClickListeners;
    private GameConfiguration _gameConfiguration;
    private Ellipse[,] _tokens;

    public double Width => Application.Current.Dispatcher.Invoke(() => _canvas.ActualWidth);

    public GameCanvas(Canvas canvas)
    {
      _canvas = canvas;
      _columnClickListeners = new List<TaskCompletionSource<double>>();
      Setup(new GameConfiguration());
    }

    public void PaintMove(int row, int column, Player player)
    {
      var brush = new SolidColorBrush(Colors.White);
      var animation = new ColorAnimation
      {
        From = Colors.White,
        To = player == Player.Player1
          ? Colors.Crimson
          : Colors.Gold,
        Duration = TimeSpan.FromSeconds(0.1)
      };
      _tokens[row, column].Fill = brush;
      brush.BeginAnimation(SolidColorBrush.ColorProperty, animation);
    }

    public void PaintWin((int Y, int X) point1, (int Y, int X) point2)
    {
      var cellWidth = _canvas.ActualWidth / _gameConfiguration.ColumnCount;
      var cellHeight = _canvas.ActualHeight / _gameConfiguration.RowCount;
      var lineWidth = cellWidth / 6;
      var line = new Line
      {
        Stroke = Brushes.DarkGreen,
        X1 = point1.X * cellWidth,
        X2 = point2.X * cellWidth,
        Y1 = - point1.Y * cellHeight,
        Y2 = - point2.Y * cellHeight,
        StrokeThickness = lineWidth,
        StrokeStartLineCap = PenLineCap.Round,
        StrokeEndLineCap = PenLineCap.Round,
        RenderTransformOrigin = new Point(0.5, 0.5)
      };
      Canvas.SetLeft(line, cellWidth/2);
      Canvas.SetBottom(line, cellHeight/2);
      _canvas.Children.Add(line);
      
    }

    public void Clear()
    {
      foreach (UIElement canvasChild in _canvas.Children)
      {
        if (canvasChild is Line == false) continue;
        
        _canvas.Children.Remove(canvasChild);
        break;
      }

      foreach (var token in _tokens)
      {
        token.Fill = Brushes.White;
      }
    }

    public void OnClicked(object sender, MouseButtonEventArgs args)
    {
      _columnClickListeners.ForEach(l => l.SetResult(Mouse.GetPosition(_canvas).X));
      _columnClickListeners.Clear();
    }

    public void Subscribe(TaskCompletionSource<double> tsc)
    {
      _columnClickListeners.Add(tsc);
    }

    public void Setup(GameConfiguration gameConfiguration)
    {
      _gameConfiguration = gameConfiguration;
      _tokens = new Ellipse[gameConfiguration.RowCount, gameConfiguration.ColumnCount];
      var cellWidth = _canvas.ActualWidth / _gameConfiguration.ColumnCount;
      var cellHeight = _canvas.ActualHeight / _gameConfiguration.RowCount;
      var offset = 5;
      for (var y = 0; y < gameConfiguration.RowCount; y++)
      {
        for (var x = 0; x < gameConfiguration.ColumnCount; x++)
        {
          var ellipse = new Ellipse
          {
            Fill = Brushes.White,
            Width = cellWidth - 2*offset,
            Height = cellHeight - 2*offset,
          };
          Canvas.SetLeft(ellipse, x * cellWidth + offset);
          Canvas.SetBottom(ellipse, y * cellHeight + offset);
          _canvas.Children.Add(ellipse);
          _tokens[y, x] = ellipse;
        }
      }
    }
  }
}
