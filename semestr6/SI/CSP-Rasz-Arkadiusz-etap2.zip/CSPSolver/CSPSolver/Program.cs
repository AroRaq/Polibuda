﻿using System;
using System.Linq;
using Common;
using CSPSolver.WordFill;
using WordFillFileReader = Common.WordFillFileReader;

namespace CSPSolver
{
  internal class Program
  {
    static void Main(string[] args)
    {
      var program = new Program();
      program.SolveWordFills();

    }

    private void SolveSudokus()
    {
      var reader = new SudokuFileReader();
      var sudokuData = reader.ReadFromFile("Problems/Sudoku.csv");
      var sudokus = sudokuData.Select(data => new Sudoku.Sudoku(data));

      foreach (var sudoku in sudokus)
      {
        var solver = new RecursiveProblemSolver();
        Console.WriteLine($"ID: {sudoku.Id}");
        var (isSolved, solutions) = solver.GetAllSolutions(sudoku);
        Console.WriteLine(isSolved
          ? solutions.Aggregate("", (s, problem) => s += $"\n{problem}")
          : "No solution found!");
        Console.WriteLine(solver.Stats);
        Console.WriteLine();
      }
    }

    private void SolveWordFills()
    {
      var reader = new WordFillFileReader();
      var problemData = reader.ReadFromFiles();
      var problems = problemData.Select(data => new WordFill.WordFill(data));

      foreach (var problem in problems)
      {
        var solver = new RecursiveProblemSolver();
        Console.WriteLine();
        var (isSolved, solutions) = solver.GetAllSolutions(problem);
        Console.WriteLine(isSolved
          ? solutions.Aggregate("", (s, p) => s += $"\n{p}")
          : "No solution found!");
        Console.WriteLine(solver.Stats);
        Console.WriteLine();
      }
    }
  }
}
