﻿namespace CSPSolver.Mapping
{

}
