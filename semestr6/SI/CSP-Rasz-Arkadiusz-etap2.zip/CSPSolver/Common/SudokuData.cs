﻿namespace Common
{
  public class SudokuData
  {
    public int Id { get; set; }
    public int Difficulty { get; set; }
    public int?[,] Board { get; set; }
  }
}