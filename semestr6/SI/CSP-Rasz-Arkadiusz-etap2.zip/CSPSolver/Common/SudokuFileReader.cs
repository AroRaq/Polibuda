﻿using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using CsvHelper;

namespace Common
{
  public class SudokuFileReader
  {
    public List<SudokuData> ReadFromFile(string path)
    {
      using var reader = new StreamReader(path);
      using var csvReader = new CsvReader(reader, CultureInfo.InvariantCulture); 
      var dtos = csvReader.GetRecords<SudokuDto>();
      return dtos.Select(dto => new SudokuData
      {
        Id = dto.Id,
        Difficulty = dto.Difficulty,
        Board = StringToBoard(dto.Puzzle)
      }).ToList();
    }


    private int?[,] StringToBoard(string s)
    {
      var board = new int?[9, 9];
      var x = 0;
      var y = 0;
      foreach (var c in s)
      {
        if (c == '.')
          board[y, x] = null;
        else
          board[y, x] = (int)char.GetNumericValue(c);
        x++;
        if (x >= 9)
        {
          x = 0;
          y++;
        }
      }

      return board;
    }
  }


  internal class SudokuDto
  {
    public int Id { get; set; }
    public int Difficulty { get; set; }
    public string Puzzle { get; set; }
    public string Solution { get; set; }
  }
}
