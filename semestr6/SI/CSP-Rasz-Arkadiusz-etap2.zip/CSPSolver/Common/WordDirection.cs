﻿namespace Common
{
  public enum WordDirection
  {
    Right,
    Down
  }
}