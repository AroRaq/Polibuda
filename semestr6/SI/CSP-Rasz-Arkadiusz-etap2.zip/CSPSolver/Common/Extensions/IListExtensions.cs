﻿using System;
using System.Collections.Generic;

namespace Common.Extensions
{
  public static class IListExtensions
  {
    private static readonly Lazy<Random> _random = new Lazy<Random>(() => new Random());
    public static T RandomOrDefault<T>(this IList<T> list) 
    {
      if (list.Count == 0)
        return default(T);
      var idx = _random.Value.Next(list.Count);
      return list[idx];
    }
  }
}
