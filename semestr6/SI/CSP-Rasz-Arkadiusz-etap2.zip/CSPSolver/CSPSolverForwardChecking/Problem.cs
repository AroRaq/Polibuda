﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace CSPSolverForwardChecking
{
  internal abstract class Problem<TVariable, TValue>
  {
    private Stopwatch stopwatch = Stopwatch.StartNew();

    public int Id;
    public List<(TVariable Variable, List<TValue> Domain)> Variables;
    public List<(TVariable First, TVariable Second, Func<TValue, TValue, bool> Pred)> Connections;

    protected abstract Problem<TVariable, TValue> Clone();

    public abstract bool CheckConstraints(TVariable variable, TValue solution);

    public Problem<TVariable, TValue> WithValue(TVariable variable, TValue solution)
    {
      var next = this.Clone();
      next.FillVariable(variable, solution);
      var shouldStop = next.FilterDomains(variable, solution);
      return shouldStop ? null : next;
    }

    public abstract void FillVariable(TVariable variable, TValue solution);
    public abstract (TVariable variable, IEnumerable<TValue> domain) GetNextVariable();
    public abstract (TVariable variable, IEnumerable<TValue> domain) GetRandomVariable();

    protected bool FilterDomains(TVariable variable, TValue value)
    {
      Variables.RemoveAll(v => Equals(v.Variable, variable));
      FilterDomainsSpecific(variable, value);

      var shouldStop = false;
      Connections
        .Where(c => Equals(c.First, variable))
        .ToList()
        .ForEach(c =>
        {
          var (second, domain) = Variables.SingleOrDefault(v => Equals(v.Variable, c.Second));
          domain?.RemoveAll(s => !c.Pred(value, s));
          if (domain?.Count == 0) shouldStop = true;
        });
      return shouldStop;
    }

    protected abstract void FilterDomainsSpecific(TVariable variable, TValue value);

    public long Milliseconds
    {
      get
      {
        stopwatch.Stop();
        return stopwatch.ElapsedMilliseconds;
      }
    }
  }
}
