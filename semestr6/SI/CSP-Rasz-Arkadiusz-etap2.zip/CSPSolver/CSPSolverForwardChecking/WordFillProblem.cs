﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Common;
using Common.Extensions;

namespace CSPSolverForwardChecking
{
  internal class WordFillProblem : Problem<WordFillVariable, string>
  {
    private readonly char?[,] _board;

    public WordFillProblem(WordFillData data) : base()
    {
      Connections = new List<(WordFillVariable First, WordFillVariable Second, Func<string, string, bool> Pred)>();
      Variables = new List<(WordFillVariable Variable, List<string> Domain)>();
      _board = data.Board;
      PreProcess(data.Words);
    }

    public WordFillProblem(char?[,] board, IList<string> words)
    {
      Connections = new List<(WordFillVariable First, WordFillVariable Second, Func<string, string, bool> Pred)>();
      Variables = new List<(WordFillVariable Variable, List<string> Domain)>();
      _board = board;
      PreProcess(words);
    }

    private WordFillProblem(WordFillProblem other)
    {
      _board = other._board.Clone() as char?[,];
      Variables = other.Variables.Select(v => (v.Variable, v.Domain.ToList())).ToList();
      Connections = other.Connections;
    }


    private IEnumerable<(int y, int x)> Fields
    {
      get
      {
        for (var x = 0; x < _board.GetLength(1); x++)
          for (var y = 0; y < _board.GetLength(0); y++)
            yield return (y, x);
      }
    }

    private void PreProcess(IList<string> words)
    {
      var variableMap = new List<WordFillVariable>[_board.GetLength(0), _board.GetLength(1)];
      foreach (var (y, x) in Fields)
      {
        variableMap[y, x] = new List<WordFillVariable>();
      }
      foreach (var (y, x) in Fields)
      {
        if (IsWordBeginning(y, x, WordDirection.Right))
        {
          var wordLength = 0;
          var variable = new WordFillVariable(y, x, 0, WordDirection.Right);
          while (x + wordLength != _board.GetLength(1) && _board[y, x + wordLength] == ' ')
          {
            variableMap[y, x + wordLength].Add(variable);
            wordLength++;
          }
          variable.WordLength = wordLength;
          var domain = words.Where(w => w.Length == wordLength);
          Variables.Add((variable, domain.ToList()));
        }
      }

      foreach (var (y, x) in Fields)
      {
        if (IsWordBeginning(y, x, WordDirection.Down))
        {
          var wordLength = 0;
          var variable = new WordFillVariable(y, x, 0, WordDirection.Down);
          while (y + wordLength != _board.GetLength(0) && _board[y + wordLength, x] == ' ')
          {
            variableMap[y + wordLength, x].Add(variable);
            wordLength++;
          }
          variable.WordLength = wordLength;
          var domain = words.Where(w => w.Length == wordLength);
          Variables.Add((variable, domain.ToList()));
        }
      }

      foreach (var (y, x) in Fields)
      {
        if (variableMap[y, x].Count == 2)
        {
          var first = variableMap[y, x][0];
          var second = variableMap[y, x][1];
          var firstIdx = Math.Max(y - first.Y, x - first.X);
          var secondIdx = Math.Max(y - second.Y, x - second.X);
          Func<string, string, bool> del1 = (string1, string2) => string1[firstIdx] == string2[secondIdx];
          Func<string, string, bool> del2 = (string1, string2) => string1[secondIdx] == string2[firstIdx];
          Connections.Add((first, second, del1));
          // _connections.Add((second, first, del2));
        }
      }
    }

    private bool IsWordBeginning(int y, int x, WordDirection dir)
    {
      return dir switch
      {
        WordDirection.Right => (_board[y, x] == ' ' &&
                                (x == 0 || _board[y, x - 1] == null) &&
                                (x + 1 != _board.GetLength(1) && _board[y, x + 1] == ' ')),
        WordDirection.Down => (_board[y, x] == ' ' &&
                               (y == 0 || _board[y - 1, x] == null) &&
                               (y + 1 != _board.GetLength(0) && _board[y + 1, x] == ' ')),
        _ => throw new ArgumentOutOfRangeException(nameof(dir), dir, null)
      };
    }

    protected override Problem<WordFillVariable, string> Clone() => new WordFillProblem(this);

    public override bool CheckConstraints(WordFillVariable variable, string solution)
    {
      Debug.Assert(variable.WordLength == solution.Length);

      for (var i = 0; i < solution.Length; i++)
      {
        switch (variable.WordDirection)
        {
          case WordDirection.Right when _board[variable.Y, variable.X + i] != solution[i] && _board[variable.Y, variable.X + i] != ' ':
          case WordDirection.Down when _board[variable.Y + i, variable.X] != solution[i] && _board[variable.Y + i, variable.X] != ' ':
            return false;
        }
      }

      return true;
    }

    public override void FillVariable(WordFillVariable variable, string solution)
    {
      Debug.Assert(CheckConstraints(variable, solution));

      for (var i = 0; i < solution.Length; i++)
      {
        switch (variable.WordDirection)
        {
          case WordDirection.Right:
            _board[variable.Y, variable.X + i] = solution[i];
            break;
          case WordDirection.Down:
            _board[variable.Y + i, variable.X] = solution[i];
            break;
          default:
            throw new ArgumentOutOfRangeException();
        }
      }
    }



    public override (WordFillVariable variable, IEnumerable<string> domain) GetNextVariable() =>
      Variables
        .FirstOrDefault();

    public override (WordFillVariable variable, IEnumerable<string> domain) GetRandomVariable()
    {
      return Variables.RandomOrDefault();
    }

    protected override void FilterDomainsSpecific(WordFillVariable variable, string value)
    {
      Variables.ForEach(v => v.Domain.Remove(value));
    }

    public override string ToString()
    {
      var stringBuilder = new StringBuilder();
      for (var y = 0; y < _board.GetLength(0); y++)
      {
        for (var x = 0; x < _board.GetLength(1); x++)
        {
          stringBuilder.Append(_board[y, x]?.ToString() ?? "#");
        }

        stringBuilder.AppendLine();
      }

      return stringBuilder.ToString();
    }
  }
}
