﻿using System.Collections.Generic;
using System.Linq;

namespace CSPSolverForwardChecking
{
  internal class RecursiveProblemSolverWithForwardChecking
  {
    private int _nodesUntilFirst = 0;
    private int _reversesUntilFirst = 0;
    private int _nodesCount = 0;
    private int _reversesCount = 0;
    private int _solutionCount = 0;
    private long _milliseconds = 0;

    private bool _isSolved = false;


    public (bool isSolved, Problem<TVariable, T> solution) Solve<TVariable, T>(Problem<TVariable, T> problem)
    {
      if (problem == null)
        return (false, null);

      var (variable, domain) = problem.GetRandomVariable();
      if (variable == null)
        return (true, problem);
    
      foreach (var value in domain)
      {
        if (problem.CheckConstraints(variable, value))
        {
          var (isSolved, solvedSudoku) = Solve(problem.WithValue(variable, value));
          if (isSolved == true)
            return (true, solvedSudoku);
        }
      }
    
      return (false, null);
    }

    public (bool isSolved, List<Problem<TVariable, T>> solutions) GetAllSolutions<TVariable, T>(
      Problem<TVariable, T> problem)
    {
      var result = GetAllSolutionsInner(problem, 1);
      _milliseconds = problem.Milliseconds;
      return result;
    }

    private (bool isSolved, List<Problem<TVariable, T>> solutions) GetAllSolutionsInner<TVariable, T>(Problem<TVariable, T> problem, int level)
    {
      if (problem == null)
      {
        AddReverse();
        return (false, null);
      }

      var (variable, domain) = problem.GetNextVariable();
      if (variable == null)
      {
        AddSolution();
        return (true, new List<Problem<TVariable, T>> {problem});
      }

      var solutions = new List<Problem<TVariable, T>>();

      foreach (var value in domain)
      {
        AddNode();
        if (problem.CheckConstraints(variable, value))
        {
          var (isSolved, foundSolutions) = GetAllSolutionsInner(problem.WithValue(variable, value), level+1);
          if (isSolved)
            solutions.AddRange(foundSolutions);
        }
        //if (level == 2)
          //Console.WriteLine(problem.ToString());
      }

      if (solutions.Any())
        return (true, solutions);

      AddReverse();
      return (false, null);
    }

    private void AddReverse()
    {
      _reversesCount++;
      if (_isSolved == false)
        _reversesUntilFirst++;

    }

    private void AddSolution()
    {
      _isSolved = true;
      _solutionCount++;
    }

    private void AddNode()
    {
      _nodesCount++;
      if (_isSolved == false)
        _nodesUntilFirst++;
    }


    public string Stats =>
      $"Time to setup and solve            : {_milliseconds}\n" +
      $"Solutions found                    : {_solutionCount}\n" +
      $"Nodes searched until first solution: {_nodesUntilFirst}\n" +
      $"Nodes searched until all solutions : {_nodesCount}\n" +
      $"Reverses until first solution      : {_reversesUntilFirst}\n" +
      $"Reverses until all solutions       : {_reversesCount}\n";
  }
}
