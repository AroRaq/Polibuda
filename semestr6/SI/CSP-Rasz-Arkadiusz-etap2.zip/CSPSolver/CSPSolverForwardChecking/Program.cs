﻿using System;
using System.Diagnostics;
using System.Linq;
using Common;

namespace CSPSolverForwardChecking
{
  class Program
  {
    static void Main(string[] args)
    {
      var program = new Program();
      program.SolveWordFills();

    }


    private void SolveSudokus()
    {
      var reader = new SudokuFileReader();
      var problemData = reader.ReadFromFile("Problems/Sudoku.csv");

      foreach (var data in problemData)
      {
        var problem = new Sudoku(data);
        var solver = new RecursiveProblemSolverWithForwardChecking();
        Console.WriteLine($"ID: {problem.Id}");
        var (isSolved, solutions) = solver.GetAllSolutions(problem);
        Console.WriteLine(isSolved
          ? solutions.Aggregate("", (s, problem) => s += $"\n{problem}")
          : "No solution found!");
        Console.WriteLine(solver.Stats);
        Console.WriteLine();
      }
    }

    private void SolveWordFills()
    {
      var reader = new WordFillFileReader();
      var problemData = reader.ReadFromFiles();
      var problems = problemData.Select(data => new WordFillProblem(data));
      foreach (var data in problemData)
      {
        var problem = new WordFillProblem(data);
        var solver = new RecursiveProblemSolverWithForwardChecking();
        Console.WriteLine();
        var (isSolved, solutions) = solver.GetAllSolutions(problem);
        Console.WriteLine(isSolved
          // ? solutions.ToString()
          ? solutions.Aggregate("", (s, p) => s += $"\n{p}")
          : "No solution found!");
        Console.WriteLine(solver.Stats);
        Console.WriteLine();
      }
    }
  }
}
