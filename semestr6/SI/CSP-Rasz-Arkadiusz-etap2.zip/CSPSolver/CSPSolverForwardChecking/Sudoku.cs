﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using Common;
using Common.Extensions;

namespace CSPSolverForwardChecking
{
  internal class Sudoku : Problem<Vector2i, int>
  {
    private readonly int?[,] _board;

    public Sudoku(SudokuData data)
    {
      _board = data.Board;
      Id = data.Id;
      Connections = new List<(Vector2i First, Vector2i Second, Func<int, int, bool> Pred)>();
      Variables = new List<(Vector2i Variable, List<int> Domain)>();

      var domain = Enumerable.Range(1, 9);

      for (var y = 0; y < 9; y++)
        for (var x = 0; x < 9; x++)
          Variables.Add((new Vector2i(y, x), domain.ToList()));

      PreProcessConnections();

      foreach (var variable in Variables.Select(v => v.Variable).ToList())
      {
        var value = _board[variable.Y, variable.X];
        if (value != null)
        {
          FillVariable(variable, value.Value);
          FilterDomains(variable, value.Value);
        }
      }

    }

    public Sudoku(Sudoku other)
    {
      _board = other._board.Clone() as int?[,];
      Id = other.Id;
      Connections = other.Connections;
      Variables = other.Variables.Select(v => (v.Variable, v.Domain.ToList())).ToList();
    }

    protected override Problem<Vector2i, int> Clone() => new Sudoku(this);

    public void PreProcessConnections()
    {
      Func<int, int, bool> del = (value1, value2) => value1 != value2;

      foreach (var variable in Variables.Select(v => v.Variable))
      {
        var connectedFields = FieldsInSameLineHorizontal(variable)
          .Union(FieldsInSameLineVertical(variable))
          .Union(FieldsInSameSquare(variable))
          .Distinct();

        Connections.AddRange(connectedFields.Select(f => (variable, f, del)));
      }
    }

    public override bool CheckConstraints(Vector2i variable, int solution)
    {
      Debug.Assert(VerifyLines(variable, solution) && VerifySquare(variable, solution));
      return true;
    }

    public override void FillVariable(Vector2i variable, int solution)
    {
      _board[variable.Y, variable.X] = solution;
    }

    public override (Vector2i variable, IEnumerable<int> domain) GetNextVariable()
    {
      return Variables.FirstOrDefault();
    }

    public override (Vector2i variable, IEnumerable<int> domain) GetRandomVariable()
    {
      return Variables.RandomOrDefault();
    }

    protected override void FilterDomainsSpecific(Vector2i variable, int value) { }


    private bool VerifySquare(Vector2i field, int value)
    {
      var top = (field.Y / 3) * 3;
      var left = (field.X / 3) * 3;

      for (var y = top; y < top + 3; y++)
        for (var x = left; x < left + 3; x++)
          if (value == _board[y, x])
            return false;

      return true;
    }

    private bool VerifyLines(Vector2i field, int value)
    {
      for (var y = 0; y < 9; y++)
        if (_board[y, field.X] == value)
          return false;

      for (var x = 0; x < 9; x++)
        if (_board[field.Y, x] == value)
          return false;

      return true;

    }

    private IEnumerable<Vector2i> FieldsInSameLineHorizontal(Vector2i field)
    {
      return Variables
        .Select(v => v.Variable)
        .Where(v => v.Y == field.Y && !Equals(v, field));
    }

    private IEnumerable<Vector2i> FieldsInSameLineVertical(Vector2i field)
    {
      return Variables
        .Select(v => v.Variable)
        .Where(v => v.X == field.X && !Equals(v, field));
    }

    private IEnumerable<Vector2i> FieldsInSameSquare(Vector2i field)
    {
      return Variables
        .Select(v => v.Variable)
        .Where(v => v.X / 3 == field.X / 3 && v.Y / 3 == field.Y / 3 && !Equals(v, field));
    }




    public override string ToString()
    {
      var stringBuilder = new StringBuilder();
      for (var y = 0; y < 9; y++)
      {
        for (var x = 0; x < 9; x++)
        {
          stringBuilder.Append(_board[y, x]?.ToString() ?? " ");
          if (x == 2 || x == 5)
            stringBuilder.Append('|');
        }
        stringBuilder.AppendLine();
        if (y == 2 || y == 5)
          stringBuilder.AppendLine("---+---+---");
      }
      return stringBuilder.ToString();
    }
  }
}
