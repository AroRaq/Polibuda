//
// using System.Collections.Generic;
// using AutoMapper;
// using FluentAssertions;
// using Microsoft.VisualStudio.TestTools.UnitTesting;
//
// namespace CSPSolver.Test
// {
//   [TestClass]
//   public class SudokuTests
//   {
//     private readonly RecursiveProblemSolver _solver = new RecursiveProblemSolver();
//     private static List<Sudoku.Sudoku> _problems;
//
//     [ClassInitialize]
//     public static void Init(TestContext context)
//     {
//       var configuration = new MapperConfiguration(cfg =>
//         cfg.AddProfile<SudokuProfile>());
//
//       var mapper = new Mapper(configuration);
//
//       var reader = new SudokuFileReader();
//       var dtos = reader.ReadFromFile("Problems/Sudoku.csv");
//       _problems = mapper.Map<List<SudokuDTO>, List<Sudoku.Sudoku>>(dtos);
//     }
//
//
//     [TestMethod]
//     public void Solver_SolveEachSudokuOnlyFirstSolution_Benchmark()
//     {
//       foreach (var problem in _problems)
//       {
//         _solver.Solve(problem);
//       }
//     }
//
//     [TestMethod]
//     public void Solver_SolveEachSudokuAllSolutions_Benchmark()
//     {
//       foreach (var problem in _problems)
//       {
//         _solver.GetAllSolutions(problem);
//       }
//     }
//
//     [TestMethod]
//     public void Solver_SolveSudoku0_SolutionFound()
//     {
//       var problem = _problems[0];
//
//       var (isSolved, solution) = _solver.Solve(problem);
//
//       isSolved.Should().BeTrue();
//       solution.Should().NotBeNull();
//     }
//
//
//     [TestMethod]
//     public void Solver_SolveAllSudoku0_1SolutionFound()
//     {
//       var problem = _problems[0];
//
//       var (isSolved, solutions) = _solver.GetAllSolutions(problem);
//
//       isSolved.Should().BeTrue();
//       solutions.Should().NotBeNull();
//       solutions.Should().HaveCount(1);
//     }
//   }
// }
