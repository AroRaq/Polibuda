using System;
using System.Linq;
using Connect4.Model;
using Connect4.Service;
using FluentAssertions;
using Xunit;

namespace Connect4.Test
{
  public class GameStateTests
  {
    private GameStateService _gameStateService = new GameStateService();
    [Fact]
    public void PossibleColumnsToMove_Only1FilledField_CorrectColumnsReturned()
    {
      var field = new int[6, 7]
      {
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 1, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player2);
      gameState.PossibleColumnsToMove.Should().HaveCount(7);
      gameState.PossibleColumnsToMove.Should().BeInAscendingOrder();
      gameState.PossibleColumnsToMove.Should().BeEquivalentTo(new[] {0, 1, 2, 3, 4, 5, 6});
    }

    [Fact]
    public void PossibleColumnsToMove_OneColumnFull_CorrectColumnsReturned()
    {
      var field = new int[6, 7]
      {
        {0, 0, 0, 2, 0, 0, 0},
        {0, 0, 0, 1, 0, 0, 0},
        {0, 0, 0, 2, 0, 0, 0},
        {0, 0, 0, 1, 0, 0, 0},
        {0, 0, 0, 2, 0, 0, 0},
        {0, 0, 0, 1, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player1);
      gameState.PossibleColumnsToMove.Should().HaveCount(6);
      gameState.PossibleColumnsToMove.Should().BeInAscendingOrder();
      gameState.PossibleColumnsToMove.Should().BeEquivalentTo(new[] { 0, 1, 2, 4, 5, 6 });
    }

    // [Theory]
    // [InlineData(0)]
    // [InlineData(1)]
    // [InlineData(2)]
    // [InlineData(3)]
    // public void IsCompleted_HorizontalSequenceOfCountLessThanWinning_NotCompleted(int sequenceLength)
    // {
    //   var field = new int[6, 7]
    //   {
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //   }.CastToEnum<FieldState>();
    //   for (var i = 0; i < sequenceLength; i++)
    //   {
    //     field[5, i] = FieldState.Player1;
    //   }
    //   var gameState = new GameState(field, 1);
    //   gameState.IsCompleted.Should().BeFalse();
    // }
    //
    // [Theory]
    // [InlineData(0)]
    // [InlineData(1)]
    // [InlineData(2)]
    // [InlineData(3)]
    // public void IsCompleted_VerticalSequenceOfCountLessThanWinning_NotCompleted(int sequenceLength)
    // {
    //   var field = new int[6, 7]
    //   {
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //   }.CastToEnum<FieldState>();
    //   for (var i = 0; i < sequenceLength; i++)
    //   {
    //     field[i, 1] = FieldState.Player2;
    //   }
    //   var gameState = new GameState(field, 1);
    //   gameState.IsCompleted.Should().BeFalse();
    // }
    //
    // [Theory]
    // [InlineData(0)]
    // [InlineData(1)]
    // [InlineData(2)]
    // [InlineData(3)]
    // public void IsCompleted_DiagonalRisingSequenceOfCountLessThanWinning_NotCompleted(int sequenceLength)
    // {
    //   var field = new int[6, 7]
    //   {
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //   }.CastToEnum<FieldState>();
    //   for (var i = 0; i < sequenceLength; i++)
    //   {
    //     field[i, i] = FieldState.Player1;
    //   }
    //   var gameState = new GameState(field, 1);
    //   gameState.IsCompleted.Should().BeFalse();
    // }
    //
    // [Theory]
    // [InlineData(0)]
    // [InlineData(1)]
    // [InlineData(2)]
    // [InlineData(3)]
    // public void IsCompleted_DiagonalFallingSequenceOfCountLessThanWinning_NotCompleted(int sequenceLength)
    // {
    //   var field = new int[6, 7]
    //   {
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //   }.CastToEnum<FieldState>();
    //   for (var i = 0; i < sequenceLength; i++)
    //   {
    //     field[i, 6-i] = FieldState.Player2;
    //   }
    //   var gameState = new GameState(field, 1);
    //   gameState.IsCompleted.Should().BeFalse();
    // }
    //
    // [Fact]
    // public void IsCompleted_4InARow_Completed()
    // {
    //   var field = new int[6, 7]
    //   {
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //     {0, 0, 0, 0, 0, 0, 0},
    //   }.CastToEnum<FieldState>();
    //   for (var i = 0; i < 4; i++)
    //   {
    //     field[0, i] = FieldState.Player1;
    //   }
    //   var gameState = new GameState(field, 1);
    //   gameState.IsCompleted.Should().BeTrue();
    // }

    [Fact]
    public void GameData_2ThreatsToPlayer2_2EvenThreatsReturned()
    {

      var field = new int[6, 7]
      {
        {0, 1, 2, 2, 0, 0, 0},
        {0, 1, 1, 1, 0, 0, 0},
        {0, 0, 2, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player1);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] {0, 0, 0, 2});
    }

    [Fact]
    public void GameData_ThreatInBetween_1OddThreatsReturned()
    {

      var field = new int[6, 7]
      {
        {0, 1, 2, 0, 2, 0, 0},
        {0, 1, 1, 0, 1, 0, 0},
        {0, 0, 2, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player1);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] { 0, 1, 0, 0 });
    }

    [Fact]
    public void GameData_2ThreatsToPlayer2CanBeBlocked_2ThreatsReturned()
    {

      var field = new int[6, 7]
      {
        {2, 1, 2, 2, 1, 0, 0},
        {0, 1, 1, 1, 0, 0, 0},
        {0, 0, 2, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player2);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] { 0, 0, 0, 0 });
    }

    [Fact]
    public void GameData_2ColumnThreats1ImmediatelyBlocked_1ThreatsReturned()
    {

      var field = new int[6, 7]
      {
        {0, 1, 2, 0, 0, 0, 0},
        {0, 1, 2, 0, 0, 0, 0},
        {0, 1, 2, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player1);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] { 0, 0, 0, 1 });
    }

    [Fact]
    public void GameData_2ColumnThreats1ImmediatelyBlocked_1ThreatsReturned_2()
    {
      var field = new int[6, 7]
      {
        {0, 1, 2, 0, 1, 0, 0},
        {0, 1, 2, 0, 0, 0, 0},
        {0, 1, 2, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player2);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] { 0, 0, 1, 0 });
    }

    [Fact]
    public void GameData_MixedRowAndColumnThreats_1Odd2Even()
    {
      var field = new int[6, 7]
      {
        {0, 2, 2, 1, 2, 2, 0},
        {0, 2, 0, 1, 1, 1, 0},
        {0, 0, 0, 1, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player1);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] { 0, 1, 0, 2 });
    }

    [Fact]
    public void GameData_MixedRowAndColumnThreats2immediatelyBlocked_1Even()
    {
      var field = new int[6, 7]
      {
        {0, 2, 2, 1, 2, 2, 0},
        {0, 2, 0, 1, 1, 1, 0},
        {0, 0, 0, 1, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player2);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] { 0, 0, 0, 1 });
    }

    [Fact]
    public void GameData_DiagonalThreats_2Even()
    {
      var field = new int[6, 7]
      {
        {0, 2, 2, 1, 2, 2, 1},
        {0, 1, 1, 2, 1, 2, 0},
        {0, 1, 0, 0, 0, 1, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player2);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] { 0, 0, 0, 2 });
    }

    [Fact]
    public void GameData_MixedDiagonalAndRow_2Even1Odd()
    {
      var field = new int[6, 7]
      {
        {0, 2, 2, 1, 2, 2, 2},
        {0, 1, 1, 0, 1, 2, 0},
        {0, 1, 1, 0, 1, 1, 0},
        {0, 2, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player2);
      _gameStateService.EvaluateGameState(gameState).Skip(2).Should().BeEquivalentTo(new[] { 0, 2, 0, 2 });
    }

    [Fact]
    public void GameData_MixedDiagonalAndRow_CorrectWinningRows()
    {
      var field = new int[6, 7]
      {
        {0, 2, 2, 1, 2, 2, 2},
        {0, 1, 1, 0, 1, 2, 0},
        {0, 1, 1, 0, 1, 1, 0},
        {0, 2, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
      }.CastToEnum<FieldState>();
      var gameState = new GameState(field, Player.Player2);
      _gameStateService.EvaluateGameState(gameState).Take(2).Should().BeEquivalentTo(new[] { 6+6+8+5, 2+1+1 });
    }


  }

  public static class ArrayExtensions
  {
    public static T[,] CastToEnum<T>(this int[,] array)
    {
      var newArray = new T[array.GetLength(0), array.GetLength(1)];
      for (var i = 0; i < array.GetLength(0); i++)
        for (var j = 0; j < array.GetLength(1); j++)
          newArray[i, j] = (T)Enum.ToObject(typeof(T), array[i, j]);
      return newArray;
    }
  }
}
