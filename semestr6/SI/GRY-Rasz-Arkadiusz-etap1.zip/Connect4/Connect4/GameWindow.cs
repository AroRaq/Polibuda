﻿using System;
using System.Threading.Tasks;
using Connect4.Controller;
using Connect4.Model;
using Connect4.Service;
using SFML.Graphics;
using SFML.System;
using SFML.Window;

namespace Connect4
{
  internal class GameWindow
  {
    private readonly Engine _gameEngine;
    private readonly RenderWindow _renderWindow;
    private readonly RectangleShape[,] _renderedField;

    public GameWindow(Engine gameEngine)
    {
      _gameEngine = gameEngine;
      _renderWindow = new RenderWindow(new VideoMode(
        (uint)_gameEngine.CurrentGameState.Configuration.ColumnCount * 100, 
        (uint)_gameEngine.CurrentGameState.Configuration.RowCount * 100), "Connect 4");
      _renderWindow.SetActive(false);
      var field = gameEngine.CurrentGameState.Field;
      _renderedField = new RectangleShape[field.GetLength(0), field.GetLength(1)];
      for (var y = 0; y < _renderedField.GetLength(0); y++)
        for (var x = 0; x < _renderedField.GetLength(1); x++)
          _renderedField[y, x] = new RectangleShape(new Vector2f(100, 100))
          {
            Position = new Vector2f(100 * x, 100 * (gameEngine.CurrentGameState.Configuration.RowCount - (y+1) ))
          };
    }

    public async void Play()
    {
      var gameTask = Task.Factory.StartNew(() =>
      {
        var gameStateService = new GameStateService();
        _gameEngine.Run(
          new MinimaxController(Player.Player1, gameStateService), 
          // new PlayerController(), 
          new MinimaxController(Player.Player2, gameStateService));
        Console.WriteLine("Game ended!");
      });
      while (_renderWindow.IsOpen)
      {
        UpdateWindow();
      }
      await gameTask;
      Console.WriteLine("Game ended");
    }

    public void UpdateWindow()
    {
      _renderWindow.DispatchEvents();
      _renderWindow.Clear(Color.Black);

      var field = _gameEngine.CurrentGameState.Field;
      for (var y = 0; y < field.GetLength(0); y++)
      {
        for (var x = 0; x < field.GetLength(1); x++)
        {
          _renderedField[y, x].FillColor = field[y, x] switch
          {
            FieldState.Empty => Color.White,
            FieldState.Player1 => Color.Red,
            FieldState.Player2 => Color.Green
          };
          _renderWindow.Draw(_renderedField[y, x]);
        }
      }
      _renderWindow.Display();
    }

  }
}
