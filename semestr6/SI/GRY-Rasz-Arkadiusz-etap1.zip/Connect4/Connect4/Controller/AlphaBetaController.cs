﻿using Connect4.Model;

namespace Connect4.Controller
{
  internal class AlphaBetaController : IController
  {
    public int MakeMove(GameState state)
    {
      throw new System.NotImplementedException();
    }
  }
}