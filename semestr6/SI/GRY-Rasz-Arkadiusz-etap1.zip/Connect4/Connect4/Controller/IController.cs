﻿
using Connect4.Model;

namespace Connect4.Controller
{
  internal interface IController
  {
    public int MakeMove(GameState state);
  }
}
