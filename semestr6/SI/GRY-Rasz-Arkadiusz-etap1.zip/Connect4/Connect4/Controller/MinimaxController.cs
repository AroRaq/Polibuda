﻿using System;
using System.Diagnostics;
using Connect4.Model;
using Connect4.Service;

namespace Connect4.Controller
{
  internal class MinimaxController : IController
  {
    private readonly GameStateService _gameStateService;

    private readonly Player _player;
    private readonly Player _otherPlayer;
    private readonly int[] _genotype;

    public MinimaxController(Player player, GameStateService gameStateService)
    {
      _player = player;
      _gameStateService = gameStateService;
      _otherPlayer = _player == Player.Player1 ? Player.Player2 : Player.Player1;
      _genotype = player == Player.Player1
        ? new[] {1, 0, 0, 1, 0, 1}
        : new[] {-1, 1, 1, -1, 1, -1};
        // : new[] {-1, 0, 0, -1, 0, -1};
    }

    public int MakeMove(GameState state)
    {
      var (column, score) = RunMinimax(state, true, 1);
      Console.WriteLine($"{_player}: Placing on column {column} based on score of {score}");
      Debug.Assert(state.IsCompleted || column != -1);
      return column;
    }

    private (int column, int score) RunMinimax(GameState state, bool isMax, int currentDepth)
    {
      if (state.WinningPlayer != null)
        return (-1, state.WinningPlayer == _player ? int.MaxValue : int.MinValue);

      if (currentDepth == 6)
      {
        var data = _gameStateService.EvaluateGameState(state);
        var res = 0;
        for (int i = 0; i < _genotype.Length; i++)
        {
          res += _genotype[i] * data[i];
        }
        return (-1, res);
      }

      var bestScore = isMax ? int.MinValue : int.MaxValue;
      var bestColumn = -1;
      foreach (var col in state.PossibleColumnsToMove)
      {
        var score = RunMinimax(state.AfterMove(col, isMax ? _player : _otherPlayer), !isMax, currentDepth + 1).score;
        if (isMax && score >= bestScore)
        {
          bestColumn = col;
          bestScore = score;
        }
        else if (!isMax && score <= bestScore)
        {
          bestColumn = col;
          bestScore = score;
        }
      }

      return (bestColumn, bestScore);
    }

  }
}