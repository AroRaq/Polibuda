﻿using System;
using Connect4.Model;

namespace Connect4.Controller
{
  internal class PlayerController : IController
  {

    public int MakeMove(GameState state)
    {
      var move = Console.ReadLine();
      Console.WriteLine($"[{move}]");
      return int.Parse(move);
      // throw new NotImplementedException();
    }
  }
}