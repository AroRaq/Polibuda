﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices.WindowsRuntime;

[assembly: InternalsVisibleTo("Connect4.Test")]
namespace Connect4.Model
{
  public class GameState
  {
    private readonly int[] _columnFillLevel;

    public GameConfiguration Configuration { get; } = new GameConfiguration();
    public Player PlayerToMove { get; private set; } = Player.Player1;
    public FieldState[,] Field { get; }
    public bool IsCompleted { get; private set; }
    public Player? WinningPlayer { get; private set; }


    internal GameState(FieldState[,] field, Player player)
    {
      Field = field;
      _columnFillLevel = new int[Configuration.ColumnCount];
      for (var i = 0; i < Configuration.ColumnCount; i++)
      {
        _columnFillLevel[i] = Configuration.RowCount;
        for (var j = 0; j < Configuration.RowCount; j++)
        {
          if (Field[j, i] == FieldState.Empty)
          {
            _columnFillLevel[i] = j;
            break;
          }
        }
      }
      PlayerToMove = player;
    }

    private GameState()
    {
      Field = new FieldState[Configuration.RowCount, Configuration.ColumnCount];
      _columnFillLevel = new int[Configuration.ColumnCount];
    }

    private GameState(GameState other)
    {
      Field = other.Field.Clone() as FieldState[,];
      _columnFillLevel = other._columnFillLevel.Clone() as int[];
    }

    public static GameState Empty => new GameState();

    public IEnumerable<int> PossibleColumnsToMove
    {
      get
      {
        for (var i = 0; i < Configuration.ColumnCount; i++)
          if (_columnFillLevel[i] < Configuration.RowCount)
            yield return i;
      }
    }


    public GameState AfterMove(int column, Player player)
    {
      Debug.Assert(PlayerToMove == player);
      var newState = new GameState(this);
      newState.FillColumn(column, player);
      return newState;
    }

    public void FillColumn(int column, Player player)
    {
      Debug.Assert(_columnFillLevel[column] < Configuration.RowCount);
      Debug.Assert(Field[_columnFillLevel[column], column] == FieldState.Empty);
      Field[_columnFillLevel[column], column] = player switch
      {
        Player.Player1 => FieldState.Player1,
        Player.Player2 => FieldState.Player2,
        _ => throw new ArgumentException(nameof(column))
      };
      IsCompleted = CheckForCompletion(_columnFillLevel[column], column);
      if (IsCompleted)
        WinningPlayer = player;
      _columnFillLevel[column]++;
      PlayerToMove = player == Player.Player1
        ? Player.Player2
        : Player.Player1;
    }

    public bool CheckForCompletion(int rowLastMove, int columnLastMove)
    {
      if (PossibleColumnsToMove.Any() == false)
        return true;

      var horizontal = CountPlayerSequence(columnLastMove, rowLastMove, 0, -1)
                         + CountPlayerSequence(columnLastMove, rowLastMove, 0, 1) - 1;
      if (horizontal == Configuration.WinningNumber)
        return true;

      var vertical = CountPlayerSequence(columnLastMove, rowLastMove, -1, 0)
                       + CountPlayerSequence(columnLastMove, rowLastMove, 1, 0) - 1;
      if (vertical == Configuration.WinningNumber)
        return true;

      var diagonal1 = CountPlayerSequence(columnLastMove, rowLastMove, 1, -1)
                       + CountPlayerSequence(columnLastMove, rowLastMove, -1, 1) - 1;
      if (diagonal1 == Configuration.WinningNumber)
        return true;

      var diagonal2 = CountPlayerSequence(columnLastMove, rowLastMove, -1, -1)
                      + CountPlayerSequence(columnLastMove, rowLastMove, 1, 1) - 1;
      if (diagonal2 == Configuration.WinningNumber)
        return true;

      return false;
    }

    private int CountPlayerSequence(int startingColumn, int startingRow, int yIncr, int xIncr)
    {
      var searchField = Field[startingRow, startingColumn];
      var count = 0;
      for (var (y, x) = (startingRow, startingColumn);
        y >= 0 && y < Configuration.RowCount && x >= 0 && x < Configuration.ColumnCount;
        y += yIncr, x += xIncr)
      {
        if (Field[y, x] != searchField)
          return count;
        count++;
      }

      return count;
    }

    public IEnumerable<FieldSequence> HorizontalSequences
    {
      get
      {
        for (var y = 0; y < Configuration.RowCount; y++)
        for (var x = 0; x < Configuration.ColumnCount - Configuration.WinningNumber + 1; x++)
          yield return new FieldSequence(Field, y, x, Configuration.WinningNumber, FieldSequence.Direction.Right);
      }
    }

    public IEnumerable<FieldSequence> VerticalSequences
    {
      get
      {
        for (var x = 0; x < Configuration.ColumnCount; x++)
        for (var y = 0; y < Configuration.RowCount - Configuration.WinningNumber + 1; y++)
          yield return new FieldSequence(Field, y, x, Configuration.WinningNumber, FieldSequence.Direction.Up);
      }
    }

    public IEnumerable<FieldSequence> DiagonalRisingSequences
    {
      get
      {
        for (var x = 0; x < Configuration.ColumnCount - Configuration.WinningNumber + 1; x++)
        for (var y = 0; y < Configuration.RowCount - Configuration.WinningNumber + 1; y++)
          yield return new FieldSequence(Field, y, x, Configuration.WinningNumber, FieldSequence.Direction.UpRight);
      }
    }

    public IEnumerable<FieldSequence> DiagonalFallingSequences
    {
      get
      {
        for (var x = 0; x < Configuration.ColumnCount - Configuration.WinningNumber + 1; x++)
        for (var y = Configuration.RowCount - 1; y >= Configuration.WinningNumber - 1; y--)
          yield return new FieldSequence(Field, y, x, Configuration.WinningNumber, FieldSequence.Direction.DownRight);
      }
    }

    public override int GetHashCode() => Field.Cast<FieldState>().Aggregate(0, HashCode.Combine);
  }



  public enum FieldState
  {
    Empty = 0,
    Player1 = 1,
    Player2 = 2
  }
}
