﻿namespace Connect4.Model
{
  public enum Player
  {
    Player1 = 1,
    Player2 = 2
  }
}