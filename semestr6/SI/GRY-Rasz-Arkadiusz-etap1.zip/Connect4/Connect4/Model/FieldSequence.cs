﻿using System;
using System.Collections.Generic;

namespace Connect4.Model
{
  public class FieldSequence
  {
    private readonly FieldState[,] _field;
    private readonly int _row;
    private readonly int _column;
    private readonly int _length;
    private readonly Direction _direction;

    public FieldSequence(FieldState[,] field, int row, int column, int length, Direction direction)
    {
      _field = field;
      _row = row;
      _column = column;
      _length = length;
      _direction = direction;
    }

    public IEnumerable<((int, int) coord, FieldState value)> Fields
    {
      get
      {
        for (var i = 0; i < _length; i++)
        {
          yield return _direction switch
          {
            Direction.Up => ((_row + i, _column), _field[_row + i, _column]),
            Direction.Right => ((_row, _column + i), _field[_row, _column + i]),
            Direction.UpRight => ((_row + i, _column + i), _field[_row + i, _column + i]),
            Direction.DownRight => ((_row - i, _column + i), _field[_row - i, _column + i]),
            _ => throw new ArgumentOutOfRangeException()
          };
        }
      }
    }

    public enum Direction
    {
      Up,
      Right,
      UpRight,
      DownRight
    }
  }
}
