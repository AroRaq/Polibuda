﻿namespace Connect4.Model
{
  public class GameConfiguration
  {
    public int WinningNumber { get; set; } = 4;
    public int RowCount { get; set; } = 6;
    public int ColumnCount { get; set; } = 7;
  }
}