﻿using Connect4.Controller;
using Connect4.Model;

namespace Connect4
{
  internal class Engine
  {
    public IController Run(IController player1, IController player2)
    {
      while (true)
      {
        var player1Move = player1.MakeMove(CurrentGameState);
        CurrentGameState.FillColumn(player1Move, Player.Player1);
        if (CurrentGameState.IsCompleted)
          return player1;

        var player2Move = player2.MakeMove(CurrentGameState);
        CurrentGameState.FillColumn(player2Move, Player.Player2);
        if (CurrentGameState.IsCompleted)
          return player2;

        if (CurrentGameState.IsCompleted)
          return null;
      }
    }

    public GameState CurrentGameState { get; } = GameState.Empty;
  }
}
