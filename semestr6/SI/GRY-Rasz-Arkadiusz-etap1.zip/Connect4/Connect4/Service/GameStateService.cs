﻿using System;
using System.Collections.Generic;
using System.Linq;
using Connect4.Extensions;
using Connect4.Model;

namespace Connect4.Service
{
  internal class GameStateService
  {
    private readonly Dictionary<int, int[]> _cache = new Dictionary<int, int[]>();

    public int[] EvaluateGameState(GameState state) => 
      _cache.GetOrCreate(state.GetHashCode(), () => EvaluateGameStateInner(state));

    public int[] EvaluateGameStateInner(GameState state)
    {
      var winningRowsForP1 = 0;
      var winningRowsForP2 = 0;
      var oddThreatsToP1 = 0;
      var oddThreatsToP2 = 0;
      var evenThreatsToP1 = 0;
      var evenThreatsToP2 = 0;

      var sequences = state.HorizontalSequences
        .Union(state.VerticalSequences)
        .Union(state.DiagonalRisingSequences)
        .Union(state.DiagonalFallingSequences);

      foreach (var sequence in sequences)
      {
        var p1fields = 0;
        var p2fields = 0;
        var emptyFields = new List<(int, int)>(state.Configuration.WinningNumber);
        foreach (var ((_y, _x), value) in sequence.Fields)
        {
          switch (value)
          {
            case FieldState.Player1:
              p1fields++;
              break;
            case FieldState.Player2:
              p2fields++;
              break;
            case FieldState.Empty:
              emptyFields.Add((_y, _x));
              break;
            default:
              throw new ArgumentOutOfRangeException();
          }
        }

        if (p1fields == state.Configuration.WinningNumber - 1 && p2fields == 0)
        {
          var (_y, _x) = emptyFields.Single();
          if (state.PlayerToMove == Player.Player1)
            if (_x % 2 == 0) evenThreatsToP2++;
            else oddThreatsToP2++;
          else if (state.PlayerToMove == Player.Player2)
          {
            if (_y == 0 || state.Field[_y - 1, _x] != FieldState.Empty)
            {
            } //Don't count easily blocked moves
            else if (_x % 2 == 0) evenThreatsToP2++;
            else oddThreatsToP2++;
          }
        }
        else if (p2fields == state.Configuration.WinningNumber - 1 && p1fields == 0)
        {
          var (_y, _x) = emptyFields.Single();
          if (state.PlayerToMove == Player.Player2)
            if (_x % 2 == 0) evenThreatsToP1++;
            else oddThreatsToP1++;
          else if (state.PlayerToMove == Player.Player1)
          {
            if (_y == 0 || state.Field[_y - 1, _x] != FieldState.Empty)
            {
            } //Don't count easily blocked moves
            else if (_x % 2 == 0) evenThreatsToP1++;
            else oddThreatsToP1++;
          }
        }

        if (p1fields > 0 && p2fields == 0)
          winningRowsForP1++;
        else if (p2fields > 0 && p1fields == 0)
          winningRowsForP2++;
      }

      return new[]
        {winningRowsForP1, winningRowsForP2, oddThreatsToP1, oddThreatsToP2, evenThreatsToP1, evenThreatsToP2};

    }
  }
}
