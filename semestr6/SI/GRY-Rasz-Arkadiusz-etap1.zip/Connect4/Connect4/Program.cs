﻿using System;
using SFML.Graphics;
using SFML.Window;

namespace Connect4
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Hello World!");
      var engine = new Engine();
      var gameWindow = new GameWindow(engine);
      gameWindow.Play();
    }
  }
}
